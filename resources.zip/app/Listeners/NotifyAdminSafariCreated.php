<?php

namespace App\Listeners;

use App\Events\SafariCreationCompleted;
use App\Helpers\UserHelper;
use App\Mail\DynamicMail;
use App\Models\Admin;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

/**
 * NotifyAdminSafariCreated Listener
 *
 * Sends notification to admin when a new Safari creation workflow completes.
 * Uses existing DynamicMail flow with NotificationTemplate system.
 */
class NotifyAdminSafariCreated implements ShouldQueue
{
    use InteractsWithQueue;

    /**
     * Handle the event
     *
     * @param SafariCreationCompleted $event
     * @return void
     */
    public function handle(SafariCreationCompleted $event): void
    {
        $safari = $event->safari;

        try {
            // Prepare template data
            $data = [
                'safari_title' => $safari->title,
                'park_name' => $safari->park->name ?? 'N/A',
                'min_price' => number_format($safari->min_price_pp ?? 0),
                'max_price' => number_format($safari->max_price_pp ?? 0),
                'days' => $safari->day ?? 0,
                'nights' => $safari->night ?? 0,
                'created_at' => $safari->created_at->format('Y-m-d H:i:s'),
                'year' => date('Y'),
            ];

            // Parse template using existing flow
            $parsed = UserHelper::parseTemplate('SAFARI_CREATED', $data);

            // Send email notification to admin using DynamicMail
            $adminEmail = Admin::find(1)->email ?? config('mail.from.address');

            Mail::to($adminEmail)
                ->queue(new DynamicMail($parsed['subject'], $parsed['body']));

            // Log the activity
            Log::channel('activity')->info('Safari creation completed', [
                'safari_id' => $safari->id,
                'safari_title' => $safari->title,
                'created_by' => $safari->created_by,
                'created_at' => now(),
            ]);

            // Optional: Activity logging (if you use spatie/laravel-activity-log)
            if (function_exists('activity')) {
                activity('safari_creation_completed')
                    ->causedBy($user)
                    ->performedOn($safari)
                    ->withProperties([
                        'title' => $safari->title,
                        'park' => $safari->park->name ?? 'Unknown',
                        'price_range' => "$safari->min_price_pp - $safari->max_price_pp",
                    ])
                    ->log('Safari creation workflow completed');
            }
        } catch (\Exception $e) {
            Log::error('Error notifying admin about safari creation', [
                'safari_id' => $safari->id,
                'error' => $e->getMessage(),
            ]);

            // Don't throw - prevent blocking workflow
            // But log for debugging
        }
    }
}
