<?php

namespace App\Listeners;

use App\Events\PackageCreationCompleted;
use App\Helpers\UserHelper;
use App\Mail\DynamicMail;
use App\Models\Admin;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

/**
 * NotifyAdminPackageCreated Listener
 *
 * Sends notification to admin when a new Package creation workflow completes.
 * Uses existing DynamicMail flow with NotificationTemplate system.
 */
class NotifyAdminPackageCreated implements ShouldQueue
{
    use InteractsWithQueue;

    /**
     * Handle the event
     *
     * @param PackageCreationCompleted $event
     * @return void
     */
    public function handle(PackageCreationCompleted $event): void
    {
        $package = $event->package;

        try {
            // Prepare template data
            $data = [
                'package_title' => $package->title,
                'park_name' => $package->park->name ?? 'N/A',
                'min_price' => number_format($package->min_price ?? 0),
                'max_price' => number_format($package->max_price ?? 0),
                'created_at' => $package->created_at->format('Y-m-d H:i:s'),
                'year' => date('Y'),
            ];

            // Parse template using existing flow
            $parsed = UserHelper::parseTemplate('PACKAGE_CREATED', $data);

            // Send email notification to admin using DynamicMail
            $adminEmail = Admin::find(1)->email ?? config('mail.from.address');

            Mail::to($adminEmail)
                ->queue(new DynamicMail($parsed['subject'], $parsed['body']));

            // Log the activity
            Log::channel('activity')->info('Package creation completed', [
                'package_id' => $package->id,
                'package_title' => $package->title,
                'created_by' => $package->created_by,
                'created_at' => now(),
            ]);

            // Optional: Activity logging (if you use spatie/laravel-activity-log)
            if (function_exists('activity')) {
                activity('package_creation_completed')
                    ->causedBy($user)
                    ->performedOn($package)
                    ->withProperties([
                        'title' => $package->title,
                        'park' => $package->park->name ?? 'Unknown',
                        'price_range' => "$package->min_price - $package->max_price",
                    ])
                    ->log('Package creation workflow completed');
            }
        } catch (\Exception $e) {
            Log::error('Error notifying admin about package creation', [
                'package_id' => $package->id,
                'error' => $e->getMessage(),
            ]);

            // Don't throw - prevent blocking workflow
            // But log for debugging
        }
    }
}
