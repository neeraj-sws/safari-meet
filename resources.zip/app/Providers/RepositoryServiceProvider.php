<?php

namespace App\Providers;

use App\Repositories\Contracts\PackageRepositoryInterface;
use App\Repositories\PackageRepository;
use Illuminate\Support\ServiceProvider;

/**
 * RepositoryServiceProvider registers repository bindings.
 *
 * This allows dependency injection of repository interfaces throughout the application.
 * Makes it easy to swap implementations (e.g., Eloquent → Query Cache) without touching consumers.
 */
class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register repository bindings
     */
    public function register(): void
    {
        $this->app->bind(
            PackageRepositoryInterface::class,
            PackageRepository::class
        );
    }

    public function boot(): void
    {
    }
}
