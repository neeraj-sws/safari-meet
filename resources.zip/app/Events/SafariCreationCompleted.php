<?php

namespace App\Events;

use App\Models\ShareSafari;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * SafariCreationCompleted Event
 * 
 * Fired when a user completes the 3-step Safari creation workflow.
 * Listeners can:
 * - Send notifications to admins
 * - Log activity
 * - Update user statistics
 * - Trigger approval workflows
 */
class SafariCreationCompleted
{
    use Dispatchable, SerializesModels;

    public ShareSafari $safari;

    public function __construct(ShareSafari $safari)
    {
        $this->safari = $safari;
    }
}
