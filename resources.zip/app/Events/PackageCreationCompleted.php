<?php

namespace App\Events;

use App\Models\Package;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * PackageCreationCompleted Event
 * 
 * Fired when a user completes the 3-step Package creation workflow.
 * Listeners can:
 * - Send notifications to admins
 * - Log activity
 * - Update user statistics
 * - Trigger approval workflows
 */
class PackageCreationCompleted
{
    use Dispatchable, SerializesModels;

    public Package $package;

    public function __construct(Package $package)
    {
        $this->package = $package;
    }
}
