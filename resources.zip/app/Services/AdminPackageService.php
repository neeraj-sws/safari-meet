<?php

namespace App\Services;

use App\Helpers\ImageUploadHelper;
use App\Helpers\UserHelper;
use App\Models\{ItineraryPackage, Package, SafariesType};
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class AdminPackageService
{
    /**
     * Get filtered packages with pagination
     */
    public function getFilteredPackages(array $filters, int $perPage = 10)
    {
        $query = Package::with('payment')->orderBy('updated_at', 'desc');

        if (!empty($filters['search'])) {
            $query->where('title', 'like', '%' . $filters['search'] . '%');
        }

        if (isset($filters['activeState'])) {
            if ($filters['activeState'] == 1) {
                $query->where('type', 0);
            } elseif ($filters['activeState'] == 0) {
                $query->where('type', 1);
            }
        }

        if (!empty($filters['filter_park'])) {
            $query->where('park_id', $filters['filter_park']);
        }

        if (!empty($filters['filter_visitPurposes'])) {
            $query->where('visit_purpose_id', $filters['filter_visitPurposes']);
        }

        if (!empty($filters['filter_stayCategories'])) {
            $query->where('stay_category_id', $filters['filter_stayCategories']);
        }

        return $query->latest()->paginate($perPage);
    }

    /**
     * Get package counts by type
     */
    public function getPackageCounts(): array
    {
        return [
            'userCount' => Package::where('type', 1)->count(),
            'adminCount' => Package::where('type', 0)->count(),
        ];
    }

    /**
     * Create a new package
     */
    public function createPackage(array $data)
    {
        $imagePath = $this->handleImageUpload($data['display_image']);
        $slug = $this->generateUniqueSlug($data['title']);
        $ipDetails = UserHelper::UserIPDetails();

        $package = Package::create([
            'title' => $data['title'],
            'slug' => $slug,
            'park_id' => $data['park_id'],
            'visit_purpose_id' => $data['visit_purpose_id'],
            'stay_category_id' => $data['stay_category_id'],
            'min_price_pp' => $data['min_price_pp'],
            'max_price_pp' => $data['max_price_pp'],
            'display_image' => $imagePath,
            'start_tour' => $data['start_date'],
            'end_tour' => $data['end_date'],
            'no_of_safari' => $data['no_of_safari'],
            'tour_highlights' => json_encode($data['tour_highlights']),
            'organized_by' => Auth::guard('admin')->user()->id,
            'ip_address' => $ipDetails['ip_address'],
            'browser' => $ipDetails['browser'],
            'os' => $ipDetails['os'],
            'device' => $ipDetails['is_mobile'] ? 'Mobile' : 'Desktop',
        ]);

        $this->syncSafariTypes($package->id, $data['safari_type']);

        return $package;
    }

    /**
     * Update an existing package
     */
    public function updatePackage(int $id, array $data)
    {
        $package = Package::findOrFail($id);

        // Handle image update
        if (isset($data['display_image']) && $data['display_image']) {
            ImageUploadHelper::delete($data['previousImage'] ?? null);
            $imagePath = $this->handleImageUpload($data['display_image']);
        } else {
            $imagePath = $data['previousImage'] ?? $package->display_image;
        }

        // Handle slug update
        $slug = $package->slug;
        if ($data['title'] !== $package->title) {
            $slug = $this->generateUniqueSlug($data['title'], $package->id);
        }

        // Handle itinerary cleanup if start date changed
        if ($package->start_tour > $data['start_date']) {
            $this->cleanupItineraries($package->id, $data['start_date']);
        }

        $ipDetails = UserHelper::UserIPDetails();

        $package->update([
            'title' => $data['title'],
            'slug' => $slug,
            'park_id' => $data['park_id'],
            'visit_purpose_id' => $data['visit_purpose_id'],
            'stay_category_id' => $data['stay_category_id'],
            'min_price_pp' => $data['min_price_pp'],
            'max_price_pp' => $data['max_price_pp'],
            'display_image' => $imagePath,
            'end_tour' => $data['end_date'],
            'start_tour' => $data['start_date'],
            'no_of_safari' => $data['no_of_safari'],
            'tour_highlights' => json_encode($data['tour_highlights']),
            'ip_address' => $ipDetails['ip_address'],
            'browser' => $ipDetails['browser'],
            'os' => $ipDetails['os'],
            'device' => $ipDetails['is_mobile'] ? 'Mobile' : 'Desktop',
        ]);

        SafariesType::where('package_id', $package->id)->delete();
        $this->syncSafariTypes($package->id, $data['safari_type']);

        return $package;
    }

    /**
     * Delete a package
     */
    public function deletePackage(int $id): void
    {
        Package::destroy($id);
    }

    /**
     * Toggle package status
     */
    public function toggleStatus(int $id, string $field): void
    {
        $package = Package::findOrFail($id);

        switch ($field) {
            case 'status':
                $package->status = !$package->status;
                break;
            case 'popular':
                $package->popular = !$package->popular;
                break;
            case 'trending':
                $package->trending = !$package->trending;
                break;
            case 'top_rated':
                $package->top_rated = !$package->top_rated;
                break;
        }

        $package->save();
    }

    /**
     * Update published status
     */
    public function updatePublishedStatus(int $id, int $status): void
    {
        $package = Package::findOrFail($id);
        $package->is_published = $status;
        $package->save();
    }

    /**
     * Handle image upload
     */
    private function handleImageUpload($image): string
    {
        return ImageUploadHelper::upload($image, 'uploads/safari/package');
    }

    /**
     * Generate unique slug
     */
    private function generateUniqueSlug(string $title, ?int $excludeId = null): string
    {
        $baseSlug = Str::slug($title);
        $slug = $baseSlug;
        $counter = 1;

        $query = Package::where('slug', $slug);
        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        while ($query->exists()) {
            $slug = $baseSlug . '-' . $counter++;
            $query = Package::where('slug', $slug);
            if ($excludeId) {
                $query->where('id', '!=', $excludeId);
            }
        }

        return $slug;
    }

    /**
     * Sync safari types
     */
    private function syncSafariTypes(int $packageId, array $safariTypes): void
    {
        foreach ($safariTypes as $typeId) {
            SafariesType::create([
                'package_id' => $packageId,
                'safari_type_id' => $typeId,
            ]);
        }
    }

    /**
     * Cleanup itineraries when start date changes
     */
    private function cleanupItineraries(int $packageId, int $newStartDate): void
    {
        $itineraries = ItineraryPackage::where('package_id', $packageId)
            ->where('order_by', '>', $newStartDate)
            ->get();

        foreach ($itineraries as $itinerary) {
            $itinerary->packageActivities()->delete();
            $itinerary->delete();
        }
    }
}
