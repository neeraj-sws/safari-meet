<?php

namespace App\Services\Workflows;

use App\Models\Package;

/**
 * PackageCreationWorkflow Service
 *
 * Implements the step-by-step workflow for creating and completing a Package:
 * Step 1: Create basic package information
 * Step 2: Add details (inclusions, exclusions, things to carry, itinerary, FAQ)
 * Step 3: Mark as complete
 *
 * Follows SOLID Principles - same interface as SafariCreationWorkflow
 */
class PackageCreationWorkflow
{
    /**
     * Workflow steps
     */
    private const STEP_BASIC_INFO = 1;
    private const STEP_DETAILS = 2;
    private const STEP_COMPLETE = 3;

    /**
     * Create a new package with basic information
     *
     * @param array $data
     * @return Package
     */
    public function createBasicPackage(array $data): Package
    {
        $package = Package::create([
            'uuid' => \Str::uuid(),
            'title' => $data['title'],
            'slug' => \Str::slug($data['title']),
            'short_description' => $data['short_description'] ?? '',
            'package_park_id' => $data['package_park_id'],
            'start_tour' => $data['start_tour'],
            'tour_type' => $data['tour_type'] ?? 'standard',
            'min_price' => $data['min_price'],
            'max_price' => $data['max_price'],
            'no_of_person' => $data['no_of_person'],
            'display_image' => $data['display_image'] ?? null,
            'category_id' => $data['category_id'] ?? null,
            'created_by' => \Auth::id(),
            'is_package_complete' => false, // Not complete until all details added
            'status' => true,
            'is_approved' => false,
        ]);

        return $package;
    }

    /**
     * Get current workflow step
     *
     * @param Package $package
     * @return int
     */
    public function getCurrentStep(Package $package): int
    {
        // If all details are filled
        if ($this->areDetailsComplete($package)) {
            return self::STEP_COMPLETE;
        }

        // If basic info is filled
        if ($package->title && $package->package_park_id) {
            return self::STEP_DETAILS;
        }

        return self::STEP_BASIC_INFO;
    }

    /**
     * Check if all required details are complete
     *
     * @param Package $package
     * @return bool
     */
    public function areDetailsComplete(Package $package): bool
    {
        // Check if mandatory details have been filled
        $hasInclusions = $package->features()
            ->where('type', 1)
            ->exists();

        $hasItinerary = \App\Models\ItineraryPackage::where('package_id', $package->id)
            ->exists();

        $hasImage = $package->display_image !== null;

        // All mandatory fields must be complete
        return $hasImage && ($hasInclusions || $hasItinerary);
    }

    /**
     * Mark package as creation complete
     *
     * @param Package $package
     * @return bool
     */
    public function markAsComplete(Package $package): bool
    {
        if (!$this->areDetailsComplete($package)) {
            return false;
        }

        $package->update([
            'is_package_complete' => true,
            'is_approved' => false, // Needs admin approval
        ]);

        // Dispatch event for notifications
        event(new \App\Events\PackageCreationCompleted($package));

        return true;
    }

    /**
     * Get workflow progress percentage
     *
     * @param Package $package
     * @return int
     */
    public function getProgress(Package $package): int
    {
        $progress = 0;

        // Basic info: 33%
        if ($package->title && $package->package_park_id) {
            $progress += 33;
        }

        // Details: 33%
        if ($this->hasAnyDetail($package)) {
            $progress += 33;
        }

        // Complete: 34%
        if ($this->areDetailsComplete($package)) {
            $progress += 34;
        }

        return min($progress, 100);
    }

    /**
     * Check if package has any details filled
     *
     * @param Package $package
     * @return bool
     */
    private function hasAnyDetail(Package $package): bool
    {
        return $package->display_image !== null ||
            $package->features()->exists() ||
            \App\Models\ItineraryPackage::where('package_id', $package->id)->exists();
    }

    /**
     * Get required details checklist
     *
     * @param Package $package
     * @return array
     */
    public function getDetailsChecklist(Package $package): array
    {
        return [
            'display_image' => (bool)$package->display_image,
            'inclusions' => (bool)$package->features()->where('type', 1)->exists(),
            'exclusions' => (bool)$package->features()->where('type', 2)->exists(),
            'itinerary' => (bool)\App\Models\ItineraryPackage::where('package_id', $package->id)->exists(),
            'things_to_carry' => (bool)\App\Models\FeatureThingsToCarrySafari::where('package_id', $package->id)->exists(),
        ];
    }

    /**
     * Get next step URL for workflow
     *
     * @param Package $package
     * @return string
     */
    public function getNextStepUrl(Package $package): string
    {
        $currentStep = $this->getCurrentStep($package);

        return match($currentStep) {
            self::STEP_BASIC_INFO => route('admin.package.list'),
            self::STEP_DETAILS => route('admin.package.detail', ['uuid' => $package->uuid, 'tab' => 'banner']),
            self::STEP_COMPLETE => route('admin.package.list'),
            default => route('admin.package.list'),
        };
    }

    /**
     * Get workflow status message
     *
     * @param Package $package
     * @return string
     */
    public function getStatusMessage(Package $package): string
    {
        $currentStep = $this->getCurrentStep($package);

        return match($currentStep) {
            self::STEP_BASIC_INFO => 'Complete basic information to proceed',
            self::STEP_DETAILS => 'Add details and media to complete creation',
            self::STEP_COMPLETE => 'Package creation complete! Awaiting admin approval.',
            default => 'Unknown step',
        };
    }
}
