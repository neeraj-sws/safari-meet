<?php

namespace App\Services\Workflows;

use App\Models\{ShareSafari, Package};
use Illuminate\Database\Eloquent\Model;

/**
 * SafariCreationWorkflow Service
 *
 * Implements the step-by-step workflow for creating and completing a Safari/Species:
 * Step 1: Create basic safari information
 * Step 2: Add details (inclusions, exclusions, things to carry, itinerary, FAQ)
 * Step 3: Mark as complete
 *
 * Follows SOLID Principles:
 * - SRP: Single workflow responsibility
 * - OCP: Extensible for new steps without modification
 * - LSP: Works uniformly with both ShareSafari and Package
 * - ISP: Focused interface for workflow operations
 * - DIP: Depends on abstractions, not concrete implementations
 */
class SafariCreationWorkflow
{
    /**
     * Workflow steps
     */
    private const STEP_BASIC_INFO = 1;
    private const STEP_DETAILS = 2;
    private const STEP_COMPLETE = 3;

    /**
     * Create a new safari with basic information
     *
     * @param array $data
     * @return ShareSafari
     */
    public function createBasicSafari(array $data): ShareSafari
    {
        $safari = ShareSafari::create([
            'uuid' => \Str::uuid(),
            'title' => $data['title'],
            'slug' => \Str::slug($data['title']),
            'short_description' => $data['short_description'] ?? '',
            'safari_park_id' => $data['safari_park_id'],
            'day' => $data['day'],
            'night' => $data['night'],
            'no_of_safari' => $data['no_of_safari'] ?? 1,
            'visit_purpose_id' => $data['visit_purpose_id'],
            'stay_category_id' => $data['stay_category_id'],
            'min_price_pp' => $data['min_price_pp'],
            'max_price_pp' => $data['max_price_pp'],
            'total_seats' => $data['total_seats'],
            'share_seats' => $data['share_seats'],
            'category_id' => $data['category_id'] ?? null,
            'organized_by' => \Auth::id(),
            'organized_type' => $data['organized_type'] ?? 'user',
            'best_month_start' => $data['best_month_start'] ?? null,
            'best_month_end' => $data['best_month_end'] ?? null,
            'display_image' => $data['display_image'] ?? null,
            'is_create_safari_complete' => false, // Not complete until all details added
            'status' => true,
            'is_approved' => false,
        ]);

        return $safari;
    }

    /**
     * Get current workflow step
     *
     * @param ShareSafari $safari
     * @return int
     */
    public function getCurrentStep(ShareSafari $safari): int
    {
        // If all details are filled
        if ($this->areDetailsComplete($safari)) {
            return self::STEP_COMPLETE;
        }

        // If basic info is filled
        if ($safari->title && $safari->safari_park_id) {
            return self::STEP_DETAILS;
        }

        return self::STEP_BASIC_INFO;
    }

    /**
     * Check if all required details are complete
     *
     * @param ShareSafari $safari
     * @return bool
     */
    public function areDetailsComplete(ShareSafari $safari): bool
    {
        // Check if mandatory details have been filled
        $hasInclusions = $safari->featuer_safaries()
            ->where('type', 1)
            ->exists();

        $hasItinerary = \App\Models\ItineraryPackage::where('share_safari_id', $safari->shared_safari_id)
            ->exists();

        $hasImage = $safari->display_image !== null;

        // All mandatory fields must be complete
        return $hasImage && ($hasInclusions || $hasItinerary);
    }

    /**
     * Mark safari as creation complete
     *
     * @param ShareSafari $safari
     * @return bool
     */
    public function markAsComplete(ShareSafari $safari): bool
    {
        if (!$this->areDetailsComplete($safari)) {
            return false;
        }

        $safari->update([
            'is_create_safari_complete' => true,
            'is_approved' => false, // Needs admin approval
        ]);

        // Dispatch event for notifications
        event(new \App\Events\SafariCreationCompleted($safari));

        return true;
    }

    /**
     * Get workflow progress percentage
     *
     * @param ShareSafari $safari
     * @return int
     */
    public function getProgress(ShareSafari $safari): int
    {
        $progress = 0;

        // Basic info: 33%
        if ($safari->title && $safari->safari_park_id) {
            $progress += 33;
        }

        // Details: 33%
        if ($this->hasAnyDetail($safari)) {
            $progress += 33;
        }

        // Complete: 34%
        if ($this->areDetailsComplete($safari)) {
            $progress += 34;
        }

        return min($progress, 100);
    }

    /**
     * Check if safari has any details filled
     *
     * @param ShareSafari $safari
     * @return bool
     */
    private function hasAnyDetail(ShareSafari $safari): bool
    {
        return $safari->display_image !== null ||
            $safari->featuer_safaries()->exists() ||
            \App\Models\ItineraryPackage::where('share_safari_id', $safari->shared_safari_id)->exists();
    }

    /**
     * Get required details checklist
     *
     * @param ShareSafari $safari
     * @return array
     */
    public function getDetailsChecklist(ShareSafari $safari): array
    {
        return [
            'display_image' => (bool)$safari->display_image,
            'inclusions' => (bool)$safari->featuer_safaries()->where('type', 1)->exists(),
            'exclusions' => (bool)$safari->featuer_safaries()->where('type', 2)->exists(),
            'itinerary' => (bool)\App\Models\ItineraryPackage::where('share_safari_id', $safari->shared_safari_id)->exists(),
            'things_to_carry' => (bool)\App\Models\FeatureThingsToCarrySafari::where('share_safari_id', $safari->shared_safari_id)->exists(),
        ];
    }

    /**
     * Get next step URL for workflow
     *
     * @param ShareSafari $safari
     * @return string
     */
    public function getNextStepUrl(ShareSafari $safari): string
    {
        $currentStep = $this->getCurrentStep($safari);

        return match($currentStep) {
            self::STEP_BASIC_INFO => route('admin.sharedsafari.share.safari'),
            self::STEP_DETAILS => route('admin.sharedsafari.detail', ['uuid' => $safari->uuid, 'tab' => 'banner']),
            self::STEP_COMPLETE => route('admin.sharedsafari.share.safari'),
            default => route('admin.sharedsafari.share.safari'),
        };
    }

    /**
     * Get workflow status message
     *
     * @param ShareSafari $safari
     * @return string
     */
    public function getStatusMessage(ShareSafari $safari): string
    {
        $currentStep = $this->getCurrentStep($safari);

        return match($currentStep) {
            self::STEP_BASIC_INFO => 'Complete basic information to proceed',
            self::STEP_DETAILS => 'Add details and media to complete creation',
            self::STEP_COMPLETE => 'Safari creation complete! Awaiting admin approval.',
            default => 'Unknown step',
        };
    }
}
