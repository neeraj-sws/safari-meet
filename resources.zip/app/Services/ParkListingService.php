<?php

namespace App\Services;

use App\Models\Park;
use App\Models\ParkBestTimeModel;
use App\Models\ParkSpecies;
use App\Models\State;
use App\Models\StayCategory;
use App\Models\WeatherModel;

/**
 * ParkListingService
 *
 * Handles filter resolution and park query logic for Park listing flow.
 * Extracted from Livewire\Front\Park\Listing to improve testability and SRP.
 */
class ParkListingService
{
    /**
     * Resolve filter dropdown options for UI
     */
    public function resolveFilterOptions(): array
    {
        $parks = Park::with('state:state_id,name')
            ->where('status', true)
            ->get(['park_id', 'name', 'state_id']);

        $stateIds = $parks->pluck('state_id')->unique()->values();
        $states = State::whereIn('state_id', $stateIds)->pluck('name', 'state_id');

        $parkSpecies = ParkSpecies::with('speciesList:species_id,name')
            ->whereIn('park_id', $parks->pluck('park_id'))
            ->get();

        $species = $parkSpecies
            ->filter(fn($item) => $item->speciesList)
            ->mapWithKeys(fn($item) => [$item->speciesList->id => $item->speciesList->name])
            ->unique()
            ->toArray();

        $bestTimesVisits = WeatherModel::where('status', 1)->get();
        $stayCategory = StayCategory::pluck('name', 'stay_category_id');
        $park_datas = $parks->pluck('name', 'park_id');

        return [
            'states' => $states,
            'species' => $species,
            'bestTimesVisits' => $bestTimesVisits,
            'stayCategory' => $stayCategory,
            'park_datas' => $park_datas,
        ];
    }

    /**
     * Build park query with filters and return collection
     *
     * @param array $filters ['stateSelect', 'speciesSelect', 'parkSelect', 'stayCategorySelect', 'bestTimeSelect', 'orderbyfilter']
     * @param int $perPage
     * @return \Illuminate\Support\Collection
     */
    public function getFilteredParks(array $filters, int $perPage = 6)
    {
        $query = Park::with([
            'state',
            'parkBestTimes.weather',
            'wildlife.species',
            'parkSafariTypes.safari_type',
            'parkspecies'
        ])->where('status', true);

        if (!empty($filters['stateSelect'])) {
            $query->where('state_id', $filters['stateSelect']);
        }

        if (!empty($filters['speciesSelect'])) {
            $query->whereHas('parkspecies', function ($q) use ($filters) {
                $q->where('species_id', $filters['speciesSelect']);
            });
        }

        if (!empty($filters['parkSelect'])) {
            $query->where('park_id', $filters['parkSelect']);
        }

        if (!empty($filters['stayCategorySelect'])) {
            $query->where('stay_category_id', $filters['stayCategorySelect']);
        }

        if (!empty($filters['bestTimeSelect']) && is_array($filters['bestTimeSelect'])) {
            $query->whereHas('parkBestTimes', function ($q) use ($filters) {
                $q->whereIn('weathers_id', $filters['bestTimeSelect']);
            });
        }

        if (!empty($filters['orderbyfilter'])) {
            match ($filters['orderbyfilter']) {
                'popular' => $query->orderBy('popular', 'DESC'),
                'latest' => $query->orderBy('created_at', 'DESC'),
                'trending' => $query->orderBy('trending', 'DESC'),
                'top' => $query->orderBy('top_rated', 'DESC'),
                default => null,
            };
        }

        return $query->take($perPage)->get();
    }

    /**
     * Resolve display name for a selected filter
     */
    public function resolveFilterDisplayName(string $filterType, $value): ?string
    {
        return match ($filterType) {
            'state' => State::select('name')->find($value)?->name,
            'species' => ParkSpecies::with('speciesList')->where('species_id', $value)->first()?->speciesList?->name,
            'park' => Park::select('name')->find($value)?->name,
            'best_time' => WeatherModel::whereIn('park_weather_id', (array)$value)->pluck('title')->unique()->toArray(),
            default => null,
        };
    }
}
