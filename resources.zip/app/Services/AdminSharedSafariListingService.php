<?php

namespace App\Services;

use App\Models\ShareSafari;
use Illuminate\Pagination\LengthAwarePaginator;

/**
 * AdminSharedSafariListingService
 *
 * Handles admin-side shared safari listing with filters and status management.
 * Extracted from Livewire\Admin\ShareSafari\ShareSafariCrud to improve testability and SRP.
 */
class AdminSharedSafariListingService
{
    /**
     * Get counts by organizer type
     *
     * @return array ['userCount', 'adminCount', 'agentCount']
     */
    public function getOrganizerCounts(): array
    {
        return [
            'userCount' => ShareSafari::where('organized_type', 'user')->count(),
            'adminCount' => ShareSafari::where('organized_type', 'admin')->count(),
            'agentCount' => ShareSafari::where('organized_type', 'agent')->count(),
        ];
    }

    /**
     * Get filtered and paginated shared safaris
     *
     * @param array $filters ['search', 'activeState', 'filter_park', 'filter_visitPurposes', 'filter_stayCategories']
     * @param int $perPage
     * @return LengthAwarePaginator
     */
    public function getFilteredSafaris(array $filters, int $perPage = 10): LengthAwarePaginator
    {
        $query = ShareSafari::with('payments')->orderBy('updated_at', 'desc');

        // Search filter
        if (!empty($filters['search'])) {
            $query->where(function ($q) use ($filters) {
                $q->where('title', 'like', '%' . $filters['search'] . '%');
            });
        }

        // Organizer type filter
        if (!empty($filters['activeState'])) {
            $organizerType = match ((int)$filters['activeState']) {
                1 => 'admin',
                2 => 'user',
                3 => 'agent',
                default => null,
            };

            if ($organizerType) {
                $query->where('organized_type', $organizerType);
            }
        }

        // Park filter
        if (!empty($filters['filter_park'])) {
            $query->where('safari_park_id', $filters['filter_park']);
        }

        // Visit purpose filter
        if (!empty($filters['filter_visitPurposes'])) {
            $query->where('visit_purpose_id', $filters['filter_visitPurposes']);
        }

        // Stay category filter
        if (!empty($filters['filter_stayCategories'])) {
            $query->where('stay_category_id', $filters['filter_stayCategories']);
        }

        return $query->latest()->paginate($perPage);
    }

    /**
     * Toggle safari status
     */
    public function toggleStatus(int $safariId, string $field): bool
    {
        $safari = ShareSafari::findOrFail($safariId);
        $safari->$field = !$safari->$field;
        return $safari->save();
    }

    /**
     * Update approval status and send notification
     *
     * @param int $safariId
     * @param int $status (1 = approved, 0 = rejected)
     */
    public function updateApprovalStatus(int $safariId, int $status): void
    {
        $safari = ShareSafari::findOrFail($safariId);
        $safari->is_approved = $status;
        $safari->save();

        $notificationCode = $status == 1 ? 12 : 13;

        createNotification(
            $notificationCode,
            $safari->organized_by,
            $safari->organized_type == 'admin' ? 'App\Models\Admin' : 'App\Models\User',
            1,
            'App\Models\Admin',
            [
                'safari_id' => $safari->id,
                'safari_name' => $safari->title ?? null,
                'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
            ]
        );
    }

    /**
     * Delete shared safari
     */
    public function deleteSafari(int $safariId): bool
    {
        return ShareSafari::destroy($safariId) > 0;
    }
}
