<?php

namespace App\Services;

use App\Helpers\UserHelper;
use App\Mail\DynamicMail;
use App\Models\Enquiry;
use Illuminate\Support\Facades\Mail;

/**
 * ParkDetailService
 *
 * Handles enquiry creation and email dispatch for Park detail flow.
 * Extracted from Livewire\Front\Park\Detail to improve testability and SRP.
 */
class ParkDetailService
{
    /**
     * Create park enquiry and dispatch confirmation + admin notification emails
     *
     * @param array $data ['user_name', 'user_email', 'user_number', 'safaris', 'travellers', 'accommodation', 'start_date', 'end_date', 'park_id', 'currentUrl']
     * @return Enquiry
     */
    public function createEnquiry(array $data): Enquiry
    {
        $IdAddress = UserHelper::UserIPDetails();

        $enquiry = Enquiry::create([
            'name' => $data['user_name'],
            'email' => $data['user_email'],
            'number' => $data['user_number'],
            'safaris' => $data['safaris'],
            'travellers' => $data['travellers'],
            'accommodation_id' => $data['accommodation'],
            'type' => 'Park',
            'type_id' => $data['park_id'],
            'url' => $data['currentUrl'],
            'ip_address' => $IdAddress['ip_address'],
            'source' => 'Park Details',
            'browser' => $IdAddress['browser'],
            'os' => $IdAddress['os'],
            'device' => $IdAddress['is_mobile'] ? 'Mobile' : 'Desktop',
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
        ]);

        // Send user confirmation email
        $userData = [
            'name' => $enquiry->name,
            'number' => $enquiry->number,
            'safaris' => $enquiry->safaris,
            'travellers' => $enquiry->travellers,
            'accommodation' => $enquiry?->accommodation?->title,
            'start_date' => $enquiry->start_date,
            'end_date' => $enquiry->end_date,
        ];

        $parsedUser = UserHelper::parseTemplate('USERENQUIRY', $userData);

        Mail::to($enquiry->email)->queue(
            new DynamicMail($parsedUser['subject'], $parsedUser['body'])
        );

        // Send admin notification email
        $adminData = [
            'name' => $enquiry->name,
            'number' => $enquiry->number,
            'safaris' => $enquiry->safaris,
            'travellers' => $enquiry->travellers,
            'accommodation' => $enquiry?->accommodation?->title,
            'start_date' => $enquiry->start_date,
            'end_date' => $enquiry->end_date,
            'admin_view_url' => route('admin.enquiries'),
            'url' => $data['currentUrl'],
            'received_at' => $enquiry->created_at,
        ];

        $parsedAdmin = UserHelper::parseTemplate('ADMINENQURY', $adminData);

        Mail::to('shifankhan@yopmail.com')->queue(
            new DynamicMail($parsedAdmin['subject'], $parsedAdmin['body'])
        );

        return $enquiry;
    }
}
