<?php

namespace App\Services;

use App\Helpers\UserHelper;
use App\Mail\DynamicMail;
use App\Models\JoinSharedSafari;
use App\Models\Report;
use App\Models\SafariAllottedSeat;
use App\Models\SafariConversation;
use App\Models\SafariDiscussion;
use App\Models\ShareSafari;
use App\Models\Wishlist;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class SharedSafariDetailService
{
    public function joinSafari(ShareSafari $safari, int $userId): array
    {
        JoinSharedSafari::firstOrCreate([
            'user_id' => $userId,
            'share_safari_id' => $safari->id,
        ]);

        $conversation = SafariConversation::where('share_safari_id', $safari->id)
            ->where(function ($q) use ($safari, $userId) {
                $q->where('creator_id', $safari->organized_by)
                    ->where('participant_id', $userId);
            })
            ->first();

        if (!$conversation) {
            SafariConversation::create([
                'share_safari_id'  => $safari->id,
                'creator_id'       => $safari->organized_by,
                'creator_type'     => ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User',
                'participant_id'   => $userId,
                'participant_type' => get_class(Auth::guard('web')->user()),
                'organized_type'   => $safari->organized_type,
            ]);
        }

        $sender_type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
        createNotification(
            1,
            $safari->organized_by,
            $sender_type,
            $userId,
            get_class(Auth::guard('web')->user()),
            [
                'user_name' => Auth::guard('web')->user()->name,
                'safari_id' => $safari->id,
                'safari_name' => $safari->title ?? null,
                'message' => Auth::guard('web')->user()->name . ' joined ' . $safari->title . ' shared safari successfully.',
                'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
            ]
        );

        return ['success' => true, 'message' => "Your join request has been sent to the host. Feel free to connect using the Personal Chat option below."];
    }

    public function leaveSafari(ShareSafari $safari, int $joinSafariId, int $userId): array
    {
        $join = JoinSharedSafari::find($joinSafariId);
        if (!$join) {
            return ['success' => false, 'message' => 'Something went wrong'];
        }

        $join->delete();

        $sender_type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
        createNotification(
            2,
            $safari->organized_by,
            $sender_type,
            $userId,
            get_class(Auth::guard('web')->user()),
            [
                'user_name' => Auth::guard('web')->user()->name,
                'safari_id' => $safari->id,
                'safari_name' => $safari->title ?? null,
                'message' => Auth::guard('web')->user()->name . ' Left ' . $safari->title . ' shared safari.',
                'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
            ]
        );

        return ['success' => true, 'message' => 'Leave Shared Safari Successfully'];
    }

    public function allotSeat(ShareSafari $safari, int $targetUserId, int $seatNumber): array
    {
        if ($seatNumber <= 0) {
            return ['success' => false, 'message' => 'Seat must be greater than 0'];
        }

        $checkUser = SafariAllottedSeat::with('allottedUser')
            ->where('user_id', $targetUserId)
            ->where('shared_safari_id', $safari->id)
            ->first();

        $existingSeat = $checkUser?->number_of_seat ?? 0;

        $totalAllottedSeats = SafariAllottedSeat::where('shared_safari_id', $safari->id)
            ->sum('number_of_seat');

        $totalSeatCount = ($totalAllottedSeats - $existingSeat) + $seatNumber;

        if ($totalSeatCount > $safari->share_seats) {
            return ['success' => false, 'message' => "Only " . ($safari->share_seats - ($totalAllottedSeats - $existingSeat)) . " seats are available."];
        }

        if ($checkUser) {
            $checkUser->number_of_seat = $seatNumber;
            $checkUser->save();
            $user = $checkUser->allottedUser;

            $data = [
                "email_subject" => "Your Safari Seat Has Been Updated",
                'name' => $user->name,
                "message_body" => "Your seat details have been updated by the Safari Organizer. Please review the updated details below.",
                "safaris" => $safari->title,
                "start_date" => $safari->day,
                "end_date" => $safari->night,
                "seat_count" => $seatNumber,
                'year' => date('Y'),
            ];
            $parsed = UserHelper::parseTemplate('SEATALLOTED', $data);
            Mail::to($user->email)->queue(new DynamicMail($parsed['subject'], $parsed['body']));

            $type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
            createNotification(
                6,
                $user->id,
                get_class($user),
                $safari->organized_by,
                $type,
                [
                    'user_name' => Auth::guard('web')->user()->name,
                    'safari_id' => $safari->id,
                    'safari_name' => $safari->title ?? null,
                    'message' => Auth::guard('web')->user()->name . ' Left ' . $safari->title . ' shared safari.',
                    'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
                ]
            );
        } else {
            $safarialloted = SafariAllottedSeat::create([
                'shared_safari_id' => $safari->id,
                'user_id' => $targetUserId,
                'number_of_seat' => $seatNumber,
            ]);
            $safarialloted->load('allottedUser');
            $user = $safarialloted->allottedUser;

            $data = [
                "email_subject" => "Your Safari " . $safari->title . " Seat Has Been Allotted",
                'name' => $user->name,
                "message_body" => "Good news! Your seat for the Shared Safari has been successfully allotted. Please check the details below.",
                "safaris" => $safari->title,
                "start_date" => $safari->day,
                "end_date" => $safari->night,
                "seat_count" => $seatNumber,
                'year' => date('Y'),
            ];
            $parsed = UserHelper::parseTemplate('SEATALLOTED', $data);
            Mail::to($user->email)->queue(new DynamicMail($parsed['subject'], $parsed['body']));

            $type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
            createNotification(
                7,
                $user->id,
                get_class($user),
                $safari->organized_by,
                $type,
                [
                    'user_name' => Auth::guard('web')->user()->name,
                    'safari_id' => $safari->id,
                    'safari_name' => $safari->title ?? null,
                    'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
                ]
            );
        }

        $isSeatFull = ($totalSeatCount == $safari->share_seats);

        $allottedUserIds = SafariAllottedSeat::where('shared_safari_id', $safari->id)->pluck('user_id');
        $interestedUsers = JoinSharedSafari::with('user')
            ->where('share_safari_id', $safari->id)
            ->whereNotIn('user_id', $allottedUserIds)
            ->get();

        $wishlistUsers = Wishlist::with('user')
            ->where('shared_safari_id', $safari->id)
            ->whereNotIn('user_id', $allottedUserIds)
            ->get();

        $allUsers = $interestedUsers
            ->merge($wishlistUsers)
            ->filter(fn($item) => !empty($item->user))
            ->unique('user_id')
            ->values();

        foreach ($allUsers as $entry) {
            $user = $entry->user;
            if (!$user || empty($user->email)) {
                continue;
            }

            $type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
            createNotification(
                10,
                $user->id,
                get_class($user),
                $safari->organized_by,
                $type,
                [
                    'user_name' => Auth::guard('web')->user()->name,
                    'safari_id' => $safari->id,
                    'safari_name' => $safari->title ?? null,
                    'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
                ]
            );

            $data = [
                'email_subject' => $isSeatFull
                    ? 'Seats Of Safari ' . $safari->title . ' is Now Full'
                    : 'Good News! A Safari Seat Is Now Available',
                'name' => $user->name,
                'message_body' => $isSeatFull
                    ? 'We wanted to let you know that all seats for the safari you were interested in are now full. Stay tuned — more slots may open soon!'
                    : 'Exciting news! A seat has just become available for the safari you were interested in.',
                'safari_name' => $safari->title,
                'start_date' => $safari->day,
                'end_date' => $safari->night,
                'location' => $safari->park->name,
                'shared_safari_link' => route('shared-safari.list'),
                'package_safari_link' => route('safari-package.list'),
                'extra_message' => $isSeatFull
                    ? '😞 Unfortunately, all seats for this safari are now <strong>fully booked</strong>.<br>
        But don’t worry! You can explore other exciting <a href="' . route('shared-safari.list') . '" style="color:#1b4332;text-decoration:underline;">Shared Safaris</a>
        or check our <a href="' . route('safari-package.list') . '" style="color:#1b4332;text-decoration:underline;">Package Safaris</a>.'
                    : '🎉 Good news! A seat has become <strong>available again</strong> for this safari.<br>
        Please <strong>contact the organizer</strong> as soon as possible to confirm your booking and secure your seat.',
                'year' => date('Y'),
            ];

            $parsed = UserHelper::parseTemplate('SEAT_STATUS_UPDATE', $data);
            Mail::to($user->email)->queue(new DynamicMail($parsed['subject'], $parsed['body']));
        }

        return ['success' => true, 'message' => 'Seat Allotted Successfully', 'is_seat_full' => $isSeatFull];
    }

    public function deleteAllottedSeat(ShareSafari $safari, int $targetUserId): array
    {
        $checkUser = SafariAllottedSeat::with('allottedUser')
            ->where('user_id', $targetUserId)
            ->where('shared_safari_id', $safari->id)
            ->first();

        if (!$checkUser) {
            return ['success' => false, 'message' => 'Seat not found.'];
        }

        $wasSeatFull = (bool) $safari->is_seat_full;

        SafariAllottedSeat::where('user_id', $targetUserId)
            ->where('shared_safari_id', $safari->id)
            ->delete();

        $data = [
            "email_subject" => "Your Safari Seat Has Been Revoked",
            'name' => $checkUser->allottedUser->name,
            "message_body" => "We regret to inform you that your seat for the Shared Safari has been disallowed by the organizer. Please contact the organizer for further details.",
            "safaris" => $safari->title,
            "start_date" => $safari->day,
            "end_date" => $safari->night,
            "seat_count" => $checkUser->number_of_seat,
            'year' => date('Y'),
        ];

        $parsed = UserHelper::parseTemplate('SEATALLOTED', $data);
        Mail::to($checkUser->allottedUser->email)->queue(
            new DynamicMail($parsed['subject'], $parsed['body'])
        );

        $totalAllottedSeats = SafariAllottedSeat::where('shared_safari_id', $safari->id)
            ->sum('number_of_seat');

        $isSeatFull = ($totalAllottedSeats >= $safari->share_seats);

        if ($wasSeatFull && !$isSeatFull) {
            $allottedUserIds = SafariAllottedSeat::where('shared_safari_id', $safari->id)
                ->pluck('user_id');

            $interestedUsers = JoinSharedSafari::with('user')
                ->where('share_safari_id', $safari->id)
                ->whereNotIn('user_id', $allottedUserIds)
                ->get();

            $wishlistUsers = Wishlist::with('user')
                ->where('shared_safari_id', $safari->id)
                ->whereNotIn('user_id', $allottedUserIds)
                ->get();
            $allUsers = $interestedUsers
                ->merge($wishlistUsers)
                ->filter(fn($item) => !empty($item->user))
                ->unique('user_id')
                ->values();

            foreach ($allUsers as $entry) {
                $user = $entry->user;
                if (!$user || empty($user->email)) {
                    continue;
                }

                $type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
                createNotification(
                    11,
                    $user->id,
                    get_class($user),
                    $safari->organized_by,
                    $type,
                    [
                        'user_name' => Auth::guard('web')->user()->name,
                        'safari_id' => $safari->id,
                        'safari_name' => $safari->title ?? null,
                        'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
                    ]
                );

                $data = [
                    'email_subject' => 'Good News! A Safari Seat Is Now Available',
                    'name' => $user->name,
                    'message_body' => 'Exciting news! A seat has just become available for the safari you were interested in.',
                    'safari_name' => $safari->title,
                    'start_date' => $safari->day,
                    'end_date' => $safari->night,
                    'location' => $safari->park->name,
                    'shared_safari_link' => route('shared-safari.list'),
                    'package_safari_link' => route('safari-package.list'),
                    'extra_message' => '🎉 Good news! A seat has become <strong>available again</strong> for this safari.<br>
                    Please <strong>contact the organizer</strong> as soon as possible to confirm your booking and secure your seat.',
                    'year' => date('Y'),
                ];

                $parsed = UserHelper::parseTemplate('SEAT_STATUS_UPDATE', $data);
                Mail::to($user->email)->queue(new DynamicMail($parsed['subject'], $parsed['body']));
            }
        }

        $type = ($safari->organized_type == 'admin') ? 'App\\Models\\Admin' : 'App\\Models\\User';
        createNotification(
            5,
            $checkUser->user_id,
            'App\\Models\\User',
            $safari->organized_by,
            $type,
            [
                'user_name' => Auth::guard('web')->user()->name,
                'safari_id' => $safari->id,
                'safari_name' => $safari->title ?? null,
                'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
            ]
        );

        return ['success' => true, 'message' => 'Seat Deleted Successfully', 'is_seat_full' => $isSeatFull];
    }

    public function toggleWishlist(ShareSafari $safari, int $userId): array
    {
        $checkWishlist = Wishlist::where('shared_safari_id', $safari->id)
            ->where('user_id', $userId)
            ->first();

        if ($checkWishlist) {
            $checkWishlist->delete();

            createNotification(
                3,
                1,
                'App\\Models\\Admin',
                $userId,
                get_class(Auth::guard('web')->user()),
                [
                    'user_name' => Auth::guard('web')->user()->name,
                    'safari_id' => $safari->id,
                    'safari_name' => $safari->title ?? null,
                    'message' => Auth::guard('web')->user()->name . ' Left ' . $safari->title . ' Wishlist.',
                    'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
                ],
                'system'
            );

            return ['success' => true, 'title' => 'Add Wishlist', 'message' => 'Item Removed from Wishlist'];
        }

        Wishlist::create([
            'user_id' => $userId,
            'shared_safari_id' => $safari->id,
        ]);

        createNotification(
            4,
            1,
            'App\\Models\\Admin',
            $userId,
            get_class(Auth::guard('web')->user()),
            [
                'user_name' => Auth::guard('web')->user()->name,
                'safari_id' => $safari->id,
                'safari_name' => $safari->title ?? null,
                'message' => Auth::guard('web')->user()->name . ' added ' . $safari->title . ' Wishlist.',
                'safari_url' => route('shared-safari.detail', ['slug' => $safari->slug])
            ],
            'system'
        );

        return ['success' => true, 'title' => 'Remove Wishlist', 'message' => 'Item Added to Wishlist'];
    }

    public function reportDiscussion(ShareSafari $safari, int $discussionId, int $resionId, ?string $notes, int $userId): array
    {
        $discussion =  SafariDiscussion::where('safari_discussion_id', $discussionId)->first();
        if (!$discussion) {
            return ['success' => false, 'message' => 'Discussion not found'];
        }

        Report::create([
            'user_id' => $userId,
            'report_type' => 'comment',
            'comment_id' => $discussionId,
            'comment' => $discussion->content,
            'share_safari_id' =>  $safari->id,
            'report_resion_id' => $resionId,
            'details' => $notes,
        ]);

        return ['success' => true, 'message' => 'Report submitted successfully!'];
    }
}
