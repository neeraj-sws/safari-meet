<?php

namespace App\Services;

use App\Models\{
    FeatureThingsToCarrySafari,
    ThingsToCarry,
    FeaturePackageSafari,
    Feature,
    ParkFaq,
    Faq,
    ItineraryPackage,
    ItineraryPackageActivity,
    Package,
    ShareSafari
};
use Illuminate\Support\Collection;

/**
 * AdminCommonContentService
 *
 * Unified service for managing common content components shared between
 * ShareSafari and Package entities:
 * - Things to Carry
 * - Inclusions/Exclusions (Features)
 * - FAQs
 * - Itinerary
 *
 * This eliminates duplicate logic and provides consistent business rules
 * across both entity types (type 1 = ShareSafari, type 2 = Package).
 */
class AdminCommonContentService
{
    /**
     * Resolve the model instance based on type and ID
     *
     * @param int $type 1 for ShareSafari, 2 for Package
     * @param int $id
     * @return ShareSafari|Package
     */
    public function resolveModel(int $type, int $id)
    {
        return $type == 1
            ? ShareSafari::findOrFail($id)
            : Package::findOrFail($id);
    }

    /**
     * Get column name for relationship based on type
     *
     * @param int $type
     * @return string
     */
    public function getColumnName(int $type): string
    {
        return $type == 1 ? 'share_safari_id' : 'package_id';
    }

    // ==================== Things to Carry ====================

    /**
     * Get all available things to carry options
     *
     * @return array
     */
    public function getThingsToCarryOptions(): array
    {
        return ThingsToCarry::pluck('title', 'things_to_carry_id')->toArray();
    }

    /**
     * Get things to carry list for a model
     *
     * @param int $type
     * @param int $modelId
     * @return Collection
     */
    public function getThingsToCarryList(int $type, int $modelId): Collection
    {
        $column = $this->getColumnName($type);

        return FeatureThingsToCarrySafari::where($column, $modelId)->get();
    }

    /**
     * Get thing to carry details by ID
     *
     * @param int $id
     * @return ThingsToCarry|null
     */
    public function getThingToCarryDetails(int $id): ?ThingsToCarry
    {
        return ThingsToCarry::find($id);
    }

    /**
     * Store things to carry items
     *
     * @param int $type
     * @param int $modelId
     * @param array $items
     * @return void
     */
    public function storeThingsToCarry(int $type, int $modelId, array $items): void
    {
        $column = $this->getColumnName($type);

        foreach ($items as $item) {
            FeatureThingsToCarrySafari::create([
                $column => $modelId,
                'title' => $item['title'],
                'description' => $item['description'],
            ]);
        }
    }

    /**
     * Delete a thing to carry item
     *
     * @param int $id
     * @return bool
     */
    public function deleteThingToCarry(int $id): bool
    {
        return FeatureThingsToCarrySafari::destroy($id) > 0;
    }

    // ==================== Inclusions/Exclusions ====================

    /**
     * Get feature options by type
     *
     * @param int $featureType 1 for Inclusion, 2 for Exclusion
     * @return Collection
     */
    public function getFeatureOptions(int $featureType): Collection
    {
        return Feature::where('type', $featureType)->get();
    }

    /**
     * Get features for a model
     *
     * @param int $type
     * @param int $modelId
     * @param int $featureType
     * @return Collection
     */
    public function getFeatures(int $type, int $modelId, int $featureType): Collection
    {
        $column = $this->getColumnName($type);

        return FeaturePackageSafari::where($column, $modelId)
            ->where('type', $featureType)
            ->get();
    }

    /**
     * Get feature details by ID
     *
     * @param int $id
     * @return Feature|null
     */
    public function getFeatureDetails(int $id): ?Feature
    {
        return Feature::find($id);
    }

    /**
     * Store features (inclusions/exclusions)
     *
     * @param int $type
     * @param int $modelId
     * @param int $featureType
     * @param array $items
     * @return void
     */
    public function storeFeatures(int $type, int $modelId, int $featureType, array $items): void
    {
        $column = $this->getColumnName($type);

        foreach ($items as $item) {
            FeaturePackageSafari::create([
                $column => $modelId,
                'type' => $featureType,
                'icon' => $item['icon'],
                'title' => $item['title'],
            ]);
        }
    }

    /**
     * Delete a feature
     *
     * @param int $id
     * @return bool
     */
    public function deleteFeature(int $id): bool
    {
        return FeaturePackageSafari::destroy($id) > 0;
    }

    // ==================== FAQs ====================

    /**
     * Get FAQ options by category
     *
     * @param int $categoryId
     * @return Collection
     */
    public function getFaqOptions(int $categoryId = 2): Collection
    {
        return Faq::where('category_id', $categoryId)->get();
    }

    /**
     * Get FAQs for a park/model
     *
     * @param int $parkId
     * @return Collection
     */
    public function getParkFaqs(int $parkId): Collection
    {
        return ParkFaq::where('park_id', $parkId)->get();
    }

    /**
     * Store FAQs
     *
     * @param int $parkId
     * @param array $questions
     * @return void
     */
    public function storeFaqs(int $parkId, array $questions): void
    {
        foreach ($questions as $item) {
            if (empty(trim($item['question'])) && empty(trim($item['answer']))) {
                continue;
            }

            ParkFaq::create([
                'park_id' => $parkId,
                'question' => ucwords($item['question']),
                'answer' => $item['answer'],
            ]);
        }
    }

    /**
     * Delete an FAQ
     *
     * @param int $id
     * @return bool
     */
    public function deleteFaq(int $id): bool
    {
        return ParkFaq::destroy($id) > 0;
    }

    // ==================== Itinerary ====================

    /**
     * Calculate days for itinerary
     *
     * @param int $type
     * @param ShareSafari|Package $model
     * @return int
     */
    public function calculateItineraryDays(int $type, $model): int
    {
        if ($type == 1) {
            // ShareSafari - calculate from date range
            $startDate = \Carbon\Carbon::parse($model->start_date);
            $endDate = \Carbon\Carbon::parse($model->end_date);
            return $startDate->diffInDays($endDate) + 1;
        }

        // Package - use start_tour field
        return (int) $model->start_tour;
    }

    /**
     * Get itinerary day-wise data
     *
     * @param int $type
     * @param int $modelId
     * @return array
     */
    public function getItineraryDayWiseData(int $type, int $modelId): array
    {
        $column = $this->getColumnName($type);

        $itineraries = ItineraryPackage::where($column, $modelId)
            ->orderBy('order_by', 'asc')
            ->get();

        $dayWiseData = [];

        foreach ($itineraries as $item) {
            $dayIndex = $item->order_by;
            $activities = ItineraryPackageActivity::where('itinerary_packages_id', $item->id)
                ->select('safari_itinerary_activities_id', 'activity')
                ->get()
                ->toArray();

            $dayWiseData[$dayIndex] = [
                'id' => $item->id,
                'heading' => $item->short_description,
                'activities' => $activities,
            ];
        }

        return $dayWiseData;
    }

    /**
     * Get itinerary for a specific day
     *
     * @param int $type
     * @param int $modelId
     * @param int $day
     * @return ItineraryPackage|null
     */
    public function getItineraryByDay(int $type, int $modelId, int $day): ?ItineraryPackage
    {
        $column = $this->getColumnName($type);

        return ItineraryPackage::where($column, $modelId)
            ->where('order_by', $day)
            ->first();
    }

    /**
     * Store or update itinerary for a day
     *
     * @param int $type
     * @param int $modelId
     * @param int $day
     * @param string $heading
     * @param array $activities
     * @param int|null $itineraryId
     * @return ItineraryPackage
     */
    public function storeItinerary(
        int $type,
        int $modelId,
        int $day,
        string $heading,
        array $activities,
        ?int $itineraryId = null
    ): ItineraryPackage {
        $column = $this->getColumnName($type);

        // Create or update itinerary
        if ($itineraryId) {
            $itinerary = ItineraryPackage::findOrFail($itineraryId);
            $itinerary->update([
                'short_description' => $heading,
            ]);
        } else {
            $itinerary = ItineraryPackage::create([
                $column => $modelId,
                'order_by' => $day,
                'short_description' => $heading,
            ]);
        }

        // Delete existing activities and recreate
        ItineraryPackageActivity::where('itinerary_packages_id', $itinerary->id)->delete();

        foreach ($activities as $activity) {
            if (!empty(trim($activity))) {
                ItineraryPackageActivity::create([
                    'itinerary_packages_id' => $itinerary->id,
                    'activity' => $activity,
                ]);
            }
        }

        return $itinerary;
    }

    /**
     * Delete an itinerary with its activities
     *
     * @param int $itineraryId
     * @return bool
     */
    public function deleteItinerary(int $itineraryId): bool
    {
        $itinerary = ItineraryPackage::find($itineraryId);

        if (!$itinerary) {
            return false;
        }

        // Delete associated activities
        ItineraryPackageActivity::where('itinerary_packages_id', $itineraryId)->delete();

        // Delete itinerary
        return $itinerary->delete();
    }
}
