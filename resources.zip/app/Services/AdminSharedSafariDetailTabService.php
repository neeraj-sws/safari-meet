<?php

namespace App\Services;

use App\Models\SafariConversation;
use App\Models\SafariConversationMessage;
use App\Models\SafariDetailsDynamicTabs;
use App\Models\SharedSafariDetailsTabs;
use App\Models\SharedShafariTabs;
use App\Models\PackageTabs;
use Illuminate\Support\Collection;

/**
 * AdminSharedSafariDetailTabService
 *
 * Handles business logic for admin shared safari detail tabs including:
 * - Status toggling
 * - Dynamic tab content management (CommonTabs)
 * - Conversation and chat message operations (PersonalChat)
 *
 * Extracted from various Detail components to improve testability and SRP.
 */
class AdminSharedSafariDetailTabService
{
    /**
     * Toggle status for a detail tab
     *
     * @param int $tabId
     * @return SharedSafariDetailsTabs
     */
    public function toggleDetailTabStatus(int $tabId): SharedSafariDetailsTabs
    {
        $detailTab = SharedSafariDetailsTabs::findOrFail($tabId);
        $detailTab->status = !$detailTab->status;
        $detailTab->save();

        return $detailTab;
    }

    /**
     * Get tab title based on type and characteristic details
     *
     * @param int $type 1 for SharedSafari, other for Package
     * @param array $characterDetails
     * @return string|null
     */
    public function getTabTitle(int $type, array $characterDetails): ?string
    {
        if ($type == 1) {
            if (!empty($characterDetails)) {
                $tab = SharedShafariTabs::find($characterDetails['shared_safari_tabs_id']);
                return $tab?->title;
            }
        } else {
            if (!empty($characterDetails)) {
                $tab = PackageTabs::find($characterDetails['package_tabs_id']);
                return $tab?->title;
            }
        }

        return null;
    }

    /**
     * Get or initialize existing dynamic tab content
     *
     * @param int $type 1 for SharedSafari, other for Package
     * @param object $package
     * @param array $characterDetails
     * @return SafariDetailsDynamicTabs|null
     */
    public function getExistingDynamicTab(int $type, object $package, array $characterDetails): ?SafariDetailsDynamicTabs
    {
        $column = ($type == 1) ? 'shared_safari_id' : 'package_id';
        $column2 = ($type == 1) ? 'shared_shafari_details_tabs_id' : 'package_details_tabs_id';

        return SafariDetailsDynamicTabs::where($column, $package->id)
            ->where($column2, $characterDetails['id'])
            ->first();
    }

    /**
     * Store or update dynamic tab content
     *
     * @param int $type 1 for SharedSafari, other for Package
     * @param object $package
     * @param array $characterDetails
     * @param string $shortDescription
     * @param SafariDetailsDynamicTabs|null $existingFact
     * @return SafariDetailsDynamicTabs
     */
    public function storeDynamicTabContent(
        int $type,
        object $package,
        array $characterDetails,
        string $shortDescription,
        ?SafariDetailsDynamicTabs $existingFact = null
    ): SafariDetailsDynamicTabs {
        $column = ($type == 1) ? 'shared_safari_id' : 'package_id';
        $column2 = ($type == 1) ? 'shared_shafari_details_tabs_id' : 'package_details_tabs_id';

        if ($existingFact) {
            $existingFact->update([
                'short_description' => $shortDescription,
            ]);

            return $existingFact;
        }

        return SafariDetailsDynamicTabs::create([
            $column => $package->id,
            'short_description' => $shortDescription,
            $column2 => $characterDetails['id'],
            'key' => $package->slug,
        ]);
    }

    /**
     * Load conversations for admin user
     *
     * @param int $adminId
     * @param int $safariId
     * @return Collection
     */
    public function loadAdminConversations(int $adminId, int $safariId): Collection
    {
        return collect(
            SafariConversation::where('creator_id', $adminId)
                ->where('share_safari_id', $safariId)
                ->with(['messages' => function ($q) {
                    $q->latest();
                }, 'creator', 'participant'])
                ->get()
        );
    }

    /**
     * Load chat messages for a conversation
     *
     * @param int|null $conversationId
     * @return Collection
     */
    public function loadChatMessages(?int $conversationId): Collection
    {
        if (!$conversationId) {
            return collect();
        }

        return SafariConversationMessage::with(['sender', 'receiver'])
            ->where('safari_conversation_id', $conversationId)
            ->orderBy('created_at')
            ->get();
    }

    /**
     * Find or create conversation between admin and user
     *
     * @param int $adminId
     * @param string $adminType
     * @param int $userId
     * @param string $userType
     * @param int $safariId
     * @param string $organizedType
     * @return SafariConversation
     */
    public function getOrCreateConversation(
        int $adminId,
        string $adminType,
        int $userId,
        string $userType,
        int $safariId,
        string $organizedType
    ): SafariConversation {
        $conversation = SafariConversation::where(function ($q) use ($adminId, $userId) {
            $q->where('creator_id', $adminId)
                ->where('participant_id', $userId);
        })
            ->where('share_safari_id', $safariId)
            ->first();

        if (!$conversation) {
            $conversation = SafariConversation::create([
                'creator_id' => $adminId,
                'creator_type' => $adminType,
                'participant_id' => $userId,
                'participant_type' => $userType,
                'share_safari_id' => $safariId,
                'organized_type' => $organizedType,
            ]);
        }

        return $conversation;
    }

    /**
     * Send a chat message
     *
     * @param int $conversationId
     * @param int $senderId
     * @param string $senderType
     * @param string $message
     * @return SafariConversationMessage
     */
    public function sendChatMessage(
        int $conversationId,
        int $senderId,
        string $senderType,
        string $message
    ): SafariConversationMessage {
        $conversation = SafariConversation::findOrFail($conversationId);

        $receiverId = $conversation->creator_id === $senderId
            ? $conversation->participant_id
            : $conversation->creator_id;

        $receiverType = $conversation->creator_id === $senderId
            ? $conversation->participant_type
            : $conversation->creator_type;

        return SafariConversationMessage::create([
            'safari_conversation_id' => $conversation->id,
            'sender_id'              => $senderId,
            'sender_type'            => $senderType,
            'receiver_id'            => $receiverId,
            'receiver_type'          => $receiverType,
            'message'                => $message,
        ]);
    }
}
