<?php

namespace App\Services;

use App\Models\Feature;
use App\Models\Package;
use App\Models\Park;
use App\Models\Species;
use App\Models\State;
use App\Models\StayCategory;
use App\Models\VisitPurpose;
use App\Models\WeatherModel;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class SafariPackageListingService
{
    public function resolveFilters(array $filters): array
    {
        $stateSelect = $parkSelect = $speciesSelected = null;
        $bttvSelected = $selectedStayCategories = $inclusionSelect = $themeSelect = [];
        $minPrice = $maxPrice = $minday = $maxday = $minSafari = $maxSafari = null;
        $allFiltersValue = [];

        $map = [
            'state' => function ($val) use (&$stateSelect, &$allFiltersValue) {
                $stateSelect = State::where('name', $val)->value('state_id');
                if ($stateSelect) {
                    $allFiltersValue['state'] = $val;
                }
            },
            'park' => function ($val) use (&$parkSelect, &$allFiltersValue) {
                $parkSelect = Park::where('name', $val)->value('park_id');
                if ($parkSelect) {
                    $allFiltersValue['park'] = $val;
                }
            },
            'species' => function ($val) use (&$speciesSelected, &$allFiltersValue) {
                $speciesSelected = Species::where('name', $val)->value('species_id');
                if ($speciesSelected) {
                    $allFiltersValue['species'] = $val;
                }
            },
            'best_time' => function ($val) use (&$bttvSelected, &$allFiltersValue) {
                $titles = array_map('trim', (array) $val);
                $bttvSelected = WeatherModel::whereIn('title', $titles)->pluck('park_weather_id')->toArray();
                if ($bttvSelected) {
                    $allFiltersValue['best_time'] = $val;
                }
            },
            'stay_category' => function ($val) use (&$selectedStayCategories, &$allFiltersValue) {
                $names = array_map('trim', (array) $val);
                $selectedStayCategories = StayCategory::whereIn('name', $names)->pluck('stay_category_id')->toArray();
                if ($selectedStayCategories) {
                    $allFiltersValue['stay_category'] = $val;
                }
            },
            'inclusion' => function ($val) use (&$inclusionSelect, &$allFiltersValue) {
                $titles = array_map('trim', (array) $val);
                $inclusionSelect = Feature::whereIn('title', $titles)->pluck('features_id')->toArray();
                if ($inclusionSelect) {
                    $allFiltersValue['inclusion'] = $val;
                }
            },
            'visit_purpose' => function ($val) use (&$themeSelect, &$allFiltersValue) {
                $names = array_map('trim', (array) $val);
                $themeSelect = VisitPurpose::whereIn('name', $names)->pluck('visit_purpose_id')->toArray();
                if ($themeSelect) {
                    $allFiltersValue['visit_purpose'] = $val;
                }
            },
            'price' => function ($val) use (&$minPrice, &$maxPrice, &$allFiltersValue) {
                [$minPrice, $maxPrice] = $this->parseRange($val, '/₹(\d+)\s-\s₹(\d+)/');
                if (is_numeric($minPrice) && is_numeric($maxPrice) && $minPrice < $maxPrice) {
                    $allFiltersValue['price'] = "₹{$minPrice} - ₹{$maxPrice}";
                }
            },
            'days' => function ($val) use (&$minday, &$maxday, &$allFiltersValue) {
                [$minday, $maxday] = $this->parseRange($val, '/(\d+)\s-\s(\d+)/');
                if (is_numeric($minday) && is_numeric($maxday) && $minday < $maxday) {
                    $allFiltersValue['days'] = "{$minday} - {$maxday}";
                }
            },
            'safari' => function ($val) use (&$minSafari, &$maxSafari, &$allFiltersValue) {
                [$minSafari, $maxSafari] = $this->parseRange($val, '/(\d+)\s-\s(\d+)/');
                if (is_numeric($minSafari) && is_numeric($maxSafari) && $minSafari < $maxSafari) {
                    $allFiltersValue['safari'] = "{$minSafari} - {$maxSafari}";
                }
            },
        ];

        foreach ($filters as $key => $val) {
            if (!empty($val) && isset($map[$key])) {
                $map[$key]($val);
            }
        }

        return [
            'stateSelect' => $stateSelect,
            'parkSelect' => $parkSelect,
            'speciesSelected' => $speciesSelected,
            'bttv_selected' => $bttvSelected,
            'selectedStayCategories' => $selectedStayCategories,
            'inclusion_select' => $inclusionSelect,
            'theme_select' => $themeSelect,
            'minPrice' => $minPrice,
            'maxPrice' => $maxPrice,
            'minday' => $minday,
            'maxday' => $maxday,
            'minSafari' => $minSafari,
            'maxSafari' => $maxSafari,
            'allFiltersValue' => $allFiltersValue,
        ];
    }

    public function listPackages(array $filters, int $perPage, int $page, ?string $orderBy): LengthAwarePaginator
    {
        $query = Package::select(
            'package_id',
            'title',
            'slug',
            'park_id',
            'display_image',
            'min_price_pp',
            'max_price_pp',
            'no_of_safari',
            'start_tour',
            'visit_purpose_id',
            'stay_category_id',
            'popular',
            'trending',
            'tour_highlights',
            'top_rated',
            'created_at'
        )
            ->with([
                'park:park_id,name,state_id',
                'park.state:state_id,name'
            ])
            ->where('status', 1)
            ->where('is_published', 1);

        if (!$orderBy) {
            $query->orderBy('package_id', 'desc');
        }

        if (!empty($filters['stateSelect'])) {
            $stateId = $filters['stateSelect'];
            $query->whereHas('park.state', fn($q) => $q->where('state_id', $stateId));
        }

        if (!empty($filters['inclusion_select'])) {
            $featureIds = $filters['inclusion_select'];
            $query->whereHas('featuer_safaries', fn($q) => $q->whereIn('feature_id', $featureIds));
        }

        if (!empty($filters['parkSelect'])) {
            $query->where('park_id', $filters['parkSelect']);
        }

        if (!empty($filters['theme_select'])) {
            $query->whereIn('visit_purpose_id', $filters['theme_select']);
        }

        if (!empty($filters['bttv_selected'])) {
            $bttv = $filters['bttv_selected'];
            $query->whereHas('park.parkBestTimes', function ($q) use ($bttv) {
                $q->whereIn('weathers_id', $bttv);
            });
        }

        if (!empty($filters['speciesSelected'])) {
            $parkIDs = Park::whereHas('ParkSpecies', fn($q) => $q->where('species_id', $filters['speciesSelected']))
                ->pluck('park_id');
            $query->whereIn('park_id', $parkIDs);
        }

        if (!empty($filters['selectedStayCategories'])) {
            $query->whereIn('stay_category_id', $filters['selectedStayCategories']);
        }

        if (is_numeric($filters['minPrice'] ?? null) && is_numeric($filters['maxPrice'] ?? null)) {
            $query->whereRaw('CAST(min_price_pp AS UNSIGNED) <= ?', [$filters['maxPrice']])
                ->whereRaw('CAST(max_price_pp AS UNSIGNED) >= ?', [$filters['minPrice']]);
        }

        if (is_numeric($filters['minday'] ?? null) && is_numeric($filters['maxday'] ?? null)) {
            $query->whereRaw('CAST(start_tour AS UNSIGNED) <= ?', [$filters['maxday']])
                ->whereRaw('CAST(start_tour AS UNSIGNED) >= ?', [$filters['minday']]);
        }

        if (is_numeric($filters['minSafari'] ?? null) && is_numeric($filters['maxSafari'] ?? null)) {
            $query->whereRaw('CAST(no_of_safari AS UNSIGNED) <= ?', [$filters['maxSafari']])
                ->whereRaw('CAST(no_of_safari AS UNSIGNED) >= ?', [$filters['minSafari']]);
        }

        if ($orderBy) {
            switch ($orderBy) {
                case 'popular':
                    $query->orderBy('popular', 'DESC');
                    break;
                case 'latest':
                    $query->orderBy('created_at', 'DESC');
                    break;
                case 'trending':
                    $query->orderBy('trending', 'DESC');
                    break;
                case 'top':
                    $query->orderBy('top_rated', 'DESC');
                    break;
            }
        }

        return $query->paginate($perPage, ['*'], 'page', $page);
    }

    private function parseRange($val, string $pattern): array
    {
        if (preg_match($pattern, (string) $val, $m)) {
            return [$m[1] ?? null, $m[2] ?? null];
        }

        return [null, null];
    }
}
