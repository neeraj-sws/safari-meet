<?php

namespace App\Services;

use App\Models\JoinSharedSafari;
use App\Models\Park;
use App\Models\ShareSafari;
use App\Models\SafariConversation;
use Carbon\Carbon;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;

class SharedSafariService
{
    public function paginate(array $filters, int $perPage, int $page): LengthAwarePaginator
    {
        return $this->buildQuery($filters)
            ->paginate($perPage, ['*'], 'page', $page);
    }

    /**
     * Handle join workflow: create JoinSharedSafari and ensure conversation exists.
     */
    public function joinSafari(int $shareSafariId, int $userId): array
    {
        $safari = ShareSafari::find($shareSafariId);
        if (!$safari) {
            return ['success' => false, 'message' => 'Something went wrong'];
        }

        JoinSharedSafari::firstOrCreate([
            'user_id' => $userId,
            'share_safari_id' => $safari->id,
        ]);

        $conversation = SafariConversation::where('share_safari_id', $safari->id)
            ->where(function ($q) use ($safari, $userId) {
                $q->where('creator_id', $safari->organized_by)
                    ->where('participant_id', $userId);
            })
            ->first();

        if (!$conversation) {
            SafariConversation::create([
                'share_safari_id' => $safari->id,
                'creator_id' => $safari->organized_by,
                'participant_id' => $userId,
                'organized_type' => $safari->organized_type,
            ]);
        }

        return ['success' => true, 'message' => 'Shared Safari Join Successfully'];
    }

    public function leaveSafari(int $joinSafariId): array
    {
        $joinSafari = JoinSharedSafari::find($joinSafariId);
        if (!$joinSafari) {
            return ['success' => false, 'message' => 'Something went wrong'];
        }

        $joinSafari->delete();

        return ['success' => true, 'message' => 'Leave Shared Safari Successfully'];
    }

    private function buildQuery(array $filters): Builder
    {
        $query = ShareSafari::select(
            'shared_safari_id',
            'title',
            'slug',
            'safari_park_id',
            'display_image',
            'min_price_pp',
            'max_price_pp',
            'no_of_safari',
            'share_seats',
            'day',
            'visit_purpose_id',
            'stay_category_id',
            'is_seat_full',
            'popular',
            'trending',
            'top_rated',
            'created_at',
            'organized_by',
            'organized_type'
        )
            ->with([
                'park:park_id,name,state_id',
                'park.state:state_id,name',
                'organizer:user_id,name'
            ])
            ->where('status', 1)
            ->where('is_approved', 1)
            ->whereDate('day', '>', Carbon::today());

        if (empty($filters['orderbyfilter'] ?? null)) {
            $query->orderBy('shared_safari_id', 'desc');
        }

        if (!($filters['showBookedSafari'] ?? false)) {
            $query->where('is_seat_full', 0);
        }

        if (!empty($filters['stateSelect'])) {
            $query->whereHas('park.state', fn($q) => $q->where('state_id', $filters['stateSelect']));
        }

        if (!empty($filters['speciesSelected'])) {
            $parkIds = $this->parkIdsBySpecies($filters['speciesSelected']);
            $query->whereHas('park', fn($q) => $q->whereIn('park_id', $parkIds));
        }

        if (!empty($filters['inclusion_select'])) {
            $query->whereHas('featuer_safaries', fn($q) => $q->whereIn('feature_id', $filters['inclusion_select']));
        }

        if (!empty($filters['parkSelect'])) {
            $query->where('safari_park_id', $filters['parkSelect']);
        }

        if (!empty($filters['theme_select'])) {
            $query->whereIn('visit_purpose_id', $filters['theme_select']);
        }

        if ($this->hasValidRange($filters['minPrice'] ?? null, $filters['maxPrice'] ?? null)) {
            $query->whereRaw('CAST(min_price_pp AS UNSIGNED) <= ?', [$filters['maxPrice']])
                ->whereRaw('CAST(max_price_pp AS UNSIGNED) >= ?', [$filters['minPrice']]);
        }

        if ($this->hasValidRange($filters['minSafari'] ?? null, $filters['maxSafari'] ?? null)) {
            $query->whereRaw('CAST(no_of_safari AS UNSIGNED) <= ?', [$filters['maxSafari']])
                ->whereRaw('CAST(no_of_safari AS UNSIGNED) >= ?', [$filters['minSafari']]);
        }

        if (!empty($filters['selectedStayCategories'])) {
            $query->whereIn('stay_category_id', $filters['selectedStayCategories']);
        }

        if ($this->hasValidRange($filters['minday'] ?? null, $filters['maxday'] ?? null)) {
            $query->whereBetween('day', [
                Carbon::today()->addDays($filters['minday']),
                Carbon::today()->addDays($filters['maxday'])
            ]);
        }

        if (!empty($filters['orderbyfilter'])) {
            $this->applyOrdering($query, $filters['orderbyfilter']);
        }

        return $query;
    }

    private function parkIdsBySpecies(int $speciesId)
    {
        return Park::whereHas('ParkSpecies', fn($q) => $q->where('species_id', $speciesId))
            ->pluck('park_id');
    }

    private function hasValidRange($min, $max): bool
    {
        return is_numeric($min) && is_numeric($max) && $min <= $max;
    }

    private function applyOrdering(Builder $query, string $orderby): void
    {
        switch ($orderby) {
            case 'popular':
                $query->orderBy('popular', 'DESC');
                break;
            case 'latest':
                $query->orderBy('created_at', 'DESC');
                break;
            case 'trending':
                $query->orderBy('trending', 'DESC');
                break;
            case 'top':
                $query->orderBy('top_rated', 'DESC');
                break;
        }
    }
}
