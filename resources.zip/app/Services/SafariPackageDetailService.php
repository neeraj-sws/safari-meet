<?php

namespace App\Services;

use App\Helpers\UserHelper;
use App\Models\Package;
use App\Models\Report;
use App\Models\SafariDiscussion;
use App\Models\SafariEnquiry;
use App\Models\Wishlist;

class SafariPackageDetailService
{
    public function toggleWishlist(Package $package, int $userId): array
    {
        $checkWishlist = Wishlist::where('package_id', $package->id)
            ->where('user_id', $userId)
            ->first();

        if ($checkWishlist) {
            $checkWishlist->delete();
            return ['success' => true, 'title' => 'Add Wishlist', 'message' => 'Item Removed from Wishlist'];
        }

        Wishlist::create([
            'user_id' => $userId,
            'package_id' => $package->id,
        ]);

        return ['success' => true, 'title' => 'Remove Wishlist', 'message' => 'Item Added to Wishlist'];
    }

    public function saveEnquiry(Package $package, ?int $userId, array $payload): array
    {
        $idAddress = UserHelper::UserIPDetails();

        SafariEnquiry::create([
            'package_id' => $package->id ?? null,
            'package_owner_type' => ($package->type ?? 0) == 0 ? 'admin' : 'agent',
            'owner_id' => $package->organized_by ?? null,
            'name' => ucwords($payload['name']),
            'email' => strtolower($payload['email']),
            'country' => ucwords($payload['country']),
            'mobile_number' => $payload['mobile_number'],
            'travelers' => $payload['travelers'],
            'start_date' => $payload['start_date'],
            'people' => $payload['people'] ?? null,
            'message' => $payload['message'] ?? null,
            'user_id' => $userId,
            'ip_address' => $idAddress['ip_address'],
            'browser' => $idAddress['browser'],
            'os' => $idAddress['os'],
            'device' => $idAddress['is_mobile'] ? 'Mobile' : 'Desktop',
        ]);

        return ['success' => true, 'message' => 'Your safari enquiry has been submitted successfully!'];
    }

    public function saveDiscussion(Package $package, int $userId, string $content, ?int $parentId = null): array
    {
        SafariDiscussion::create([
            'package_id' => $package->id,
            'user_id' => $userId,
            'content' => $content,
            'is_admin' => 0,
            'parent_id' => $parentId,
        ]);

        return ['success' => true, 'message' => 'Comment added successfully!'];
    }

    public function submitReport(Package $package, int $discussionId, int $resionId, ?string $notes, int $userId): array
    {
        $discussion = SafariDiscussion::where('safari_discussion_id', $discussionId)->first();
        if (!$discussion) {
            return ['success' => false, 'message' => 'Discussion not found'];
        }

        Report::create([
            'user_id' => $userId,
            'report_type' => 'comment',
            'comment_id' => $discussionId,
            'comment' => $discussion->content,
            'package_id' =>  $package->id,
            'report_resion_id' => $resionId,
            'details' => $notes,
        ]);

        return ['success' => true, 'message' => 'Report submitted successfully!'];
    }
}
