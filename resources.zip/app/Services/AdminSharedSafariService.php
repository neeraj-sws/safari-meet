<?php

namespace App\Services;

use App\Helpers\ImageUploadHelper;
use App\Helpers\UserHelper;
use App\Models\SafariesType;
use App\Models\ShareSafari;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

/**
 * AdminSharedSafariService
 *
 * Handles admin-side shared safari create/update business logic.
 * Extracted from Livewire\Admin\ShareSafari\Add\AddSharedSafariComponent to improve testability and SRP.
 */
class AdminSharedSafariService
{
    /**
     * Validate price range (max price within 8% of min price)
     *
     * @return array ['valid' => bool, 'message' => string|null]
     */
    public function validatePriceRange(float $minPrice, float $maxPrice): array
    {
        if ($minPrice > 0) {
            $minAllowed = $minPrice;
            $maxAllowed = $minPrice * 1.08;

            if ($maxPrice < $minAllowed || $maxPrice > $maxAllowed) {
                return [
                    'valid' => false,
                    'message' => 'Max price must be greater than min price and less then 8%'
                ];
            }
        }

        return ['valid' => true, 'message' => null];
    }

    /**
     * Generate unique slug for shared safari
     */
    public function generateUniqueSlug(string $title, ?int $excludeId = null): string
    {
        $baseSlug = Str::slug($title);
        $slug = $baseSlug;
        $counter = 1;

        while (
            ShareSafari::where('slug', $slug)
                ->when($excludeId, fn($q) => $q->where('shared_safari_id', '!=', $excludeId))
                ->exists()
        ) {
            $slug = $baseSlug . '-' . $counter++;
        }

        return $slug;
    }

    /**
     * Handle image upload and delete previous if exists
     *
     * @param mixed $newImage Uploaded file or null
     * @param string|null $previousImage Path to previous image
     * @return string|null Path to uploaded image
     */
    public function handleImageUpload($newImage, ?string $previousImage): ?string
    {
        if (!$newImage) {
            return $previousImage;
        }

        $path = 'uploads/sharesafarie';
        ImageUploadHelper::delete($previousImage);
        return ImageUploadHelper::upload($newImage, $path);
    }

    /**
     * Create or update shared safari with related data
     *
     * @param array $data ['title', 'safari_park', 'day', 'night', 'safari_count', 'visit_purpose_id', 'stay_category_id', 'min_price_pp', 'max_price_pp', 'total_seats', 'share_seats', 'display_image', 'safari_type']
     * @param string|null $uuid UUID for update operation
     * @return ShareSafari
     */
    public function createOrUpdate(array $data, ?string $uuid = null): ShareSafari
    {
        $shareSafari = null;
        if ($uuid) {
            $shareSafari = ShareSafari::where('uuid', $uuid)->firstOrFail();
        }

        $slug = $this->generateUniqueSlug($data['title'], $shareSafari?->id);
        $IdAddress = UserHelper::UserIPDetails();

        $safariData = [
            'title' => $data['title'],
            'slug' => $slug,
            'safari_park_id' => $data['safari_park'],
            'day' => $data['day'],
            'night' => $data['night'],
            'no_of_safari' => $data['safari_count'],
            'visit_purpose_id' => $data['visit_purpose_id'],
            'stay_category_id' => $data['stay_category_id'],
            'min_price_pp' => $data['min_price_pp'],
            'max_price_pp' => $data['max_price_pp'],
            'total_seats' => $data['total_seats'],
            'share_seats' => $data['share_seats'],
            'display_image' => $data['display_image'],
            'ip_address' => $IdAddress['ip_address'],
            'browser' => $IdAddress['browser'],
            'os' => $IdAddress['os'],
            'device' => $IdAddress['is_mobile'] ? 'Mobile' : 'Desktop',
        ];

        if ($shareSafari) {
            $shareSafari->update($safariData);
        } else {
            $safariData['organized_by'] = Auth::guard('admin')->user()->id;
            $safariData['organized_type'] = 'admin';
            $shareSafari = ShareSafari::create($safariData);
        }

        // Update safari types
        $this->updateSafariTypes($shareSafari->id, $data['safari_type']);

        // Send notification
        $this->sendNotification($shareSafari, $uuid !== null);

        return $shareSafari;
    }

    /**
     * Update safari types for shared safari
     */
    protected function updateSafariTypes(int $safariId, array $safariTypeIds): void
    {
        SafariesType::where('shared_safari_id', $safariId)->delete();

        foreach ($safariTypeIds as $typeId) {
            SafariesType::create([
                'shared_safari_id' => $safariId,
                'safari_type_id' => $typeId,
            ]);
        }
    }

    /**
     * Send notification for shared safari creation/update
     */
    protected function sendNotification(ShareSafari $shareSafari, bool $isUpdate): void
    {
        $type = ($shareSafari->organized_type == 'admin') ? 'App\Models\Admin' : 'App\Models\User';

        createNotification(
            9,
            1,
            'App\Models\Admin',
            $shareSafari->organized_by,
            $type,
            [
                'user_name' => Auth::guard('admin')->user()->name,
                'safari_id' => $shareSafari->id,
                'safari_name' => $shareSafari->title ?? null,
                'safari_url' => route('shared-safari.detail', ['slug' => $shareSafari->slug])
            ]
        );
    }
}
