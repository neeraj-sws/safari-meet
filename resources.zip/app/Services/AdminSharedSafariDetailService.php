<?php

namespace App\Services;

use App\Models\ShareSafari;
use App\Models\SharedSafariDetailsTabs;
use App\Models\SharedShafariTabs;
use Illuminate\Support\Collection;

/**
 * AdminSharedSafariDetailService
 *
 * Handles admin-side shared safari detail tab management and characteristic data initialization.
 * Extracted from Livewire\Admin\ShareSafari\ShareSafariDetail to improve testability and SRP.
 */
class AdminSharedSafariDetailService
{
    /**
     * Get shared safari with park relation by UUID
     */
    public function getSafariByUuid(string $uuid): ?ShareSafari
    {
        return ShareSafari::with(['park'])->where('uuid', $uuid)->first();
    }

    /**
     * Get all active characteristics tabs
     */
    public function getCharacteristics(): Collection
    {
        return SharedShafariTabs::where('status', 1)->get();
    }

    /**
     * Get characteristic detail data for safari
     */
    public function getCharacteristicDetailData(int $safariId): array
    {
        $data = SharedSafariDetailsTabs::where('shared_safari_id', $safariId)->get();
        return $data->keyBy('shared_safari_tabs_id')->toArray();
    }

    /**
     * Resolve active tab from query parameter or default to first
     *
     * @param Collection $characteristics
     * @param string|null $activeTabName
     * @return mixed First matching characteristic or first available
     */
    public function resolveActiveTab(Collection $characteristics, ?string $activeTabName)
    {
        if (!empty($activeTabName)) {
            return $characteristics->first(function ($item) use ($activeTabName) {
                return \Illuminate\Support\Str::slug($item->title, '_') === $activeTabName;
            }) ?? $characteristics->first();
        }

        return $characteristics->first();
    }

    /**
     * Ensure characteristic detail tab exists for safari
     *
     * Creates entry if missing and returns the detail data.
     *
     * @param int $characteristicId
     * @param int $safariId
     * @param string $title
     * @return SharedSafariDetailsTabs
     */
    public function ensureCharacteristicDetail(int $characteristicId, int $safariId, string $title): SharedSafariDetailsTabs
    {
        return SharedSafariDetailsTabs::firstOrCreate(
            [
                'shared_safari_tabs_id' => $characteristicId,
                'shared_safari_id' => $safariId,
            ],
            [
                'title' => $title,
                'status' => true,
            ]
        );
    }

    /**
     * Get or create characteristic detail for tab toggle
     *
     * @param int $characteristicId
     * @param int $safariId
     * @param array $existingMap
     * @return array|null Detail data or null if characteristic not found
     */
    public function getOrCreateCharacteristicDetail(int $characteristicId, int $safariId, array $existingMap): ?array
    {
        if (array_key_exists($characteristicId, $existingMap)) {
            return $existingMap[$characteristicId];
        }

        $characteristic = SharedShafariTabs::find($characteristicId);

        if (!$characteristic) {
            return null;
        }

        $newEntry = $this->ensureCharacteristicDetail(
            $characteristic->id,
            $safariId,
            $characteristic->title
        );

        return $newEntry->toArray();
    }
}
