<?php

namespace App\Repositories\Contracts;

use Illuminate\Pagination\Paginator;

/**
 * PackageRepositoryInterface defines contract for Package data access.
 *
 * This interface allows swapping implementations (Eloquent, Query, etc.)
 * and makes testing easier via mocking.
 */
interface PackageRepositoryInterface
{
    /**
     * Get paginated packages with filters applied
     *
     * @param array $filters {
     *   @var int|null $stateSelect
     *   @var array|null $inclusion_select
     *   @var int|null $parkSelect
     *   @var array|null $theme_select
     *   @var array|null $bttv_selected
     *   @var int|null $speciesSelected
     *   @var array|null $selectedStayCategories
     *   @var float|null $minPrice
     *   @var float|null $maxPrice
     *   @var int|null $minday
     *   @var int|null $maxday
     *   @var int|null $minSafari
     *   @var int|null $maxSafari
     *   @var string|null $orderbyfilter
     * }
     */
    public function paginateFiltered(array $filters, int $perPage = 10): Paginator;

    /**
     * Get package by slug with all relations
     */
    public function findBySlugWithRelations(string $slug);

    /**
     * Get characteristic data by package and characteristic id
     */
    public function getCharacteristicData(int $packageId, int $characteristicId);
}
