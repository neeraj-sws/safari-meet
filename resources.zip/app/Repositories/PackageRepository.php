<?php

namespace App\Repositories;

use App\Models\Package;
use App\Models\FeaturePackageSafari;
use App\Models\FeatureThingsToCarrySafari;
use App\Models\ItineraryPackage;
use App\Models\SafariAccommodation;
use App\Models\SafariRatingHeading;
use App\Models\SafariFaq;
use App\Models\SafariDiscussion;
use App\Queries\Filters\PackageFilters;
use App\Repositories\Contracts\PackageRepositoryInterface;
use Illuminate\Pagination\Paginator;

/**
 * PackageRepository handles all Package data access logic.
 *
 * Encapsulates Eloquent queries and provides expressive methods.
 * Extracted from SafariPackageController to enable reuse and testability.
 */
class PackageRepository implements PackageRepositoryInterface
{
    /**
     * Get paginated packages with filters applied
     */
    public function paginateFiltered(array $filters, int $perPage = 10): Paginator
    {
        $query = Package::select(
            'package_id',
            'title',
            'slug',
            'park_id',
            'visit_purpose_id',
            'stay_category_id',
            'min_price_pp',
            'max_price_pp',
            'display_image',
            'end_tour',
            'start_tour',
            'tour_highlights',
            'no_of_safari'
        )->with(
            'park:park_id,name,slug,short_description',
            'park.wildlife.species:species_id,name'
        );

        // Apply filters using the filter class
        $filter = new PackageFilters($query);

        $filter->byState($filters['stateSelect'] ?? null)
            ->byInclusions($filters['inclusion_select'] ?? null)
            ->byPark($filters['parkSelect'] ?? null)
            ->byTheme($filters['theme_select'] ?? null)
            ->byBestTime($filters['bttv_selected'] ?? null)
            ->bySpecies($filters['speciesSelected'] ?? null)
            ->byStayCategory($filters['selectedStayCategories'] ?? null)
            ->byPriceRange($filters['minPrice'] ?? null, $filters['maxPrice'] ?? null)
            ->byDayRange($filters['minday'] ?? null, $filters['maxday'] ?? null)
            ->bySafariCount($filters['minSafari'] ?? null, $filters['maxSafari'] ?? null)
            ->orderBy($filters['orderbyfilter'] ?? null)
            ->published();

        return $filter->build()->paginate($perPage);
    }

    /**
     * Get package by slug with all relations
     */
    public function findBySlugWithRelations(string $slug)
    {
        return Package::select(
            'package_id',
            'title',
            'slug',
            'park_id',
            'visit_purpose_id',
            'stay_category_id',
            'min_price_pp',
            'max_price_pp',
            'display_image',
            'end_tour',
            'start_tour',
            'tour_highlights',
            'no_of_safari'
        )->with([
            'park:park_id,name',
            'detailsTabs' => function ($query) {
                $query->where('status', 1);
            }
        ])->where('slug', $slug)->first();
    }

    /**
     * Get characteristic data by characteristic id
     *
     * This method handles all the different characteristic types (itinerary, inclusions, etc.)
     */
    public function getCharacteristicData(int $packageId, int $characteristicId)
    {
        return match ($characteristicId) {
            2 => $this->getItineraryData($packageId),
            3 => $this->getInclusionsData($packageId),
            4 => $this->getExclusionsData($packageId),
            5 => $this->getAccommodationData($packageId),
            6 => $this->getRateData($packageId),
            7 => $this->getThingsToCarryData($packageId),
            8 => $this->getFAQData($packageId),
            9 => $this->getDiscussionData($packageId),
            default => $this->getDynamicData($characteristicId, $packageId),
        };
    }

    private function getItineraryData($packageId)
    {
        $itineraryPackage = ItineraryPackage::with('packageActivities')
            ->where('package_id', $packageId)
            ->get();

        return $itineraryPackage->map(function ($item) {
            return [
                'title' => $item->short_description,
                'short_dec' => $item->packageActivities->pluck('activity'),
            ];
        });
    }

    private function getInclusionsData($packageId)
    {
        return FeaturePackageSafari::select('icon', 'title')
            ->where('package_id', $packageId)
            ->where('type', 1)
            ->get();
    }

    private function getExclusionsData($packageId)
    {
        return FeaturePackageSafari::select('icon', 'title')
            ->where('package_id', $packageId)
            ->where('type', 2)
            ->get();
    }

    private function getAccommodationData($packageId)
    {
        $accommodationData = SafariAccommodation::with([
            'accommodation',
            'accommodation.amenity.amenity',
            'accommodation.image',
            'accommodation.category',
            'accommodation.cuntry',
            'accommodation.state',
            'accommodation.city',
        ])->where('package_id', $packageId)->first();

        if (!$accommodationData) {
            return null;
        }

        $baseUrl = env('APP_URL');
        $accommodation = $accommodationData->accommodation;

        $images = [];
        if (!empty($accommodation->image)) {
            foreach ($accommodation->image as $image) {
                $imgUrl = $image->image;
                if (!empty($imgUrl) && filter_var($imgUrl, FILTER_VALIDATE_URL) === false) {
                    $imgUrl = rtrim($baseUrl, '/') . '/' . ltrim($imgUrl, '/');
                }
                $images[] = $imgUrl;
            }
        }

        $amenities = [];
        if (!empty($accommodation->amenity)) {
            foreach ($accommodation->amenity as $accAmenity) {
                if (!empty($accAmenity->amenity)) {
                    $amenities[] = [
                        'id' => $accAmenity->amenity->id,
                        'title' => $accAmenity->amenity->title,
                        'icon' => $accAmenity->amenity->icon,
                    ];
                }
            }
        }

        return [
            'id' => $accommodationData->id,
            'package_id' => $accommodationData->package_id,
            'accommodation' => [
                'id' => $accommodation->id,
                'title' => $accommodation->title,
                'rating' => $accommodation->rating,
                'category' => [
                    'id' => $accommodation->category->id ?? null,
                    'name' => $accommodation->category->name ?? null,
                ],
                'country' => [
                    'id' => $accommodation->cuntry->id ?? null,
                    'name' => $accommodation->cuntry->name ?? null,
                ],
                'state' => [
                    'id' => $accommodation->state->id ?? null,
                    'name' => $accommodation->state->name ?? null,
                ],
                'city' => [
                    'id' => $accommodation->city->id ?? null,
                    'name' => $accommodation->city->name ?? null,
                ],
                'amenities' => $amenities,
                'images' => $images,
            ]
        ];
    }

    private function getRateData($packageId)
    {
        $headings = SafariRatingHeading::with('ratings.parkSafariTypes.safari_type')
            ->where('package_id', $packageId)
            ->get();

        $headingLabels = $headings->pluck('heading_label')->prepend('Safari Type')->values();

        $safariData = [];
        foreach ($headings as $heading) {
            foreach ($heading->ratings as $rating) {
                $safariType = optional($rating->parkSafariTypes->safari_type)->name;
                if (!isset($safariData[$safariType])) {
                    $safariData[$safariType] = ['Safari Type' => $safariType];
                }
                $safariData[$safariType][$heading->heading_label] = (int) $rating->price;
            }
        }

        $finalData = collect($safariData)->map(function ($row) use ($headingLabels) {
            return $headingLabels->map(function ($heading) use ($row) {
                return $row[$heading] ?? null;
            })->toArray();
        })->values();

        $responseData = $finalData;

        if ($packageId == 5) {
            $responseData = [
                'data' => $finalData
            ];
        }

        return [
            'success' => true,
            'message' => $finalData->isNotEmpty() ? 'Data found.' : 'No data found.',
            'headings' => $headingLabels,
            'data' => $responseData,
        ];
    }

    private function getThingsToCarryData($packageId)
    {
        return FeatureThingsToCarrySafari::where('package_id', $packageId)->get();
    }

    private function getFAQData($packageId)
    {
        return SafariFaq::where('package_id', $packageId)->get();
    }

    private function getDiscussionData($packageId)
    {
        return SafariDiscussion::with(['user', 'admin'])
            ->where('package_id', $packageId)
            ->get();
    }

    private function getDynamicData($characteristicId, $packageId)
    {
        // Handle any dynamic characteristics that may be added
        return [];
    }
}
