<?php

namespace App\Http\Requests\Admin\Common;

use Illuminate\Foundation\Http\FormRequest;

class StoreFaqRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $allEmpty = collect($this->questions ?? [])->every(
            fn($item) => empty(trim($item['question'] ?? '')) && empty(trim($item['answer'] ?? ''))
        );

        $rules = [
            'questions' => 'required|array',
            'questions.*.question' => 'required|string|max:500',
            'questions.*.answer' => 'required|string|max:2000',
        ];

        if ($allEmpty) {
            $rules['faq_id'] = 'required|exists:faqs,faq_id';
        }

        return $rules;
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'faq_id.required' => 'Please select a valid FAQ from the list.',
            'faq_id.exists' => 'The selected FAQ does not exist.',
            'questions.required' => 'Please add at least one FAQ question.',
            'questions.*.question.required' => 'Question is required for all FAQ items.',
            'questions.*.question.max' => 'Question cannot exceed 500 characters.',
            'questions.*.answer.required' => 'Answer is required for all FAQ items.',
            'questions.*.answer.max' => 'Answer cannot exceed 2000 characters.',
        ];
    }
}
