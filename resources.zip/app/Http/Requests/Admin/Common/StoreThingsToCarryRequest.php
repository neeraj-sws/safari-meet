<?php

namespace App\Http\Requests\Admin\Common;

use Illuminate\Foundation\Http\FormRequest;

class StoreThingsToCarryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $hasFormItems = !empty($this->formItems);

        if ($hasFormItems) {
            return [
                'formItems' => 'required|array|min:1',
                'formItems.*.title' => 'required|string|max:255',
                'formItems.*.description' => 'required|string|max:1000',
            ];
        }

        return [
            'featurethingstocarry' => 'required|exists:things_to_carries,things_to_carry_id',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'featurethingstocarry.required' => 'Please select a "Thing to Carry" from the list.',
            'featurethingstocarry.exists' => 'The selected thing to carry is invalid.',
            'formItems.required' => 'Please add at least one item.',
            'formItems.*.title.required' => 'Title is required for all items.',
            'formItems.*.title.max' => 'Title cannot exceed 255 characters.',
            'formItems.*.description.required' => 'Description is required for all items.',
            'formItems.*.description.max' => 'Description cannot exceed 1000 characters.',
        ];
    }
}
