<?php

namespace App\Http\Requests\Admin\Common;

use Illuminate\Foundation\Http\FormRequest;

class StoreItineraryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'heading' => 'required|string|max:500',
            'activity' => 'required|array|min:1',
            'activity.*' => 'required|string|max:1000',
            'activityday' => 'required|integer|min:1',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'heading.required' => 'Day heading is required.',
            'heading.max' => 'Heading cannot exceed 500 characters.',
            'activity.required' => 'Please add at least one activity.',
            'activity.min' => 'Please add at least one activity.',
            'activity.*.required' => 'Activity description is required.',
            'activity.*.max' => 'Activity description cannot exceed 1000 characters.',
            'activityday.required' => 'Day number is required.',
            'activityday.integer' => 'Day must be a valid number.',
            'activityday.min' => 'Day must be at least 1.',
        ];
    }
}
