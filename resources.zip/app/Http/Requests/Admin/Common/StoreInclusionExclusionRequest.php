<?php

namespace App\Http\Requests\Admin\Common;

use Illuminate\Foundation\Http\FormRequest;

class StoreInclusionExclusionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'items' => 'required|array|min:1',
            'items.*.icon' => 'required|string',
            'items.*.title' => 'required|string|max:255',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'items.required' => 'Please add at least one item.',
            'items.min' => 'Please add at least one item.',
            'items.*.icon.required' => 'Icon is required for all items.',
            'items.*.title.required' => 'Title is required for all items.',
            'items.*.title.max' => 'Title cannot exceed 255 characters.',
        ];
    }
}
