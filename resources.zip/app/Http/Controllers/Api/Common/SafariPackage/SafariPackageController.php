<?php

namespace App\Http\Controllers\Api\Common\SafariPackage;

use App\Http\Controllers\Api\BaseController;
use App\Models\Package;
use App\Models\SafariDiscussion;
use App\Models\SafariDetailsDynamicTabs;
use App\Repositories\Contracts\PackageRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

/**
 * SafariPackageController handles Package API endpoints.
 *
 * Refactored to delegate filtering to PackageRepository, enabling:
 * - Reusability across endpoints and channels
 * - Testability via repository mocking
 * - Easy addition of new filters without controller changes
 */
class SafariPackageController extends BaseController
{
    public function __construct(private PackageRepositoryInterface $packageRepository)
    {
    }

    /**
     * Get paginated packages with applied filters
     *
     * This method delegates all filter logic to the repository,
     * keeping the controller thin and focused on HTTP concerns.
     */
    public function getsafariPackage(Request $request)
    {
        // Delegate all filtering logic to repository
        $packages = $this->packageRepository->paginateFiltered(
            $request->only([
                'stateSelect',
                'inclusion_select',
                'parkSelect',
                'theme_select',
                'bttv_selected',
                'speciesSelected',
                'selectedStayCategories',
                'minPrice',
                'maxPrice',
                'minday',
                'maxday',
                'minSafari',
                'maxSafari',
                'orderbyfilter',
            ]),
            $request->get('perPage', 10)
        );

        $baseUrl = env('APP_URL');

        $data = collect($packages->items())->map(function ($package) use ($baseUrl) {

            $package->display_image = $package->display_image && !preg_match('/^https?:\/\//', $package->display_image)
                ? $baseUrl . '/' . ltrim($package->display_image, '/')
                : $package->display_image;

            if (isset($package->park) && isset($package->park->wildlife) && is_iterable($package->park->wildlife)) {
                foreach ($package->park->wildlife as $wildlife) {
                    if (isset($wildlife->species)) {
                        $wildlife->species->display_image = $wildlife->species->display_image && !preg_match('/^https?:\/\//', $wildlife->species->display_image)
                            ? $baseUrl . '/' . ltrim($wildlife->species->display_image, '/')
                            : $wildlife->species->display_image;

                        $wildlife->species->banner_image = $wildlife->species->banner_image && !preg_match('/^https?:\/\//', $wildlife->species->banner_image)
                            ? $baseUrl . '/' . ltrim($wildlife->species->banner_image, '/')
                            : $wildlife->species->banner_image;
                    }
                }
            }


            return $package;
        });

        return response()->json([
            'data' => $data,
            'current_page' => $packages->currentPage(),
            'last_page' => $packages->lastPage(),
            'total' => $packages->total(),
        ]);
    }

    /**
     * Get package details by slug
     */
    public function getSafariPackageDetails(Request $request)
    {
        $package = $this->packageRepository->findBySlugWithRelations($request->slug);

        if (!$package) {
            return response()->json([
                'success' => false,
                'message' => 'Package not found',
            ], 404);
        }

        $baseUrl = env('APP_URL');

        if (!empty($package->display_image) && filter_var($package->display_image, FILTER_VALIDATE_URL) === false) {
            $package->display_image = rtrim($baseUrl, '/') . '/' . ltrim($package->display_image, '/');
        }

        return response()->json([
            'success' => true,
            'data' => $package,
        ], 200);
    }

    /**
     * Get characteristic data for a package (itinerary, inclusions, accommodations, etc.)
     */
    public function getSafariPackageTabsDetails(Request $request)
    {
        if (!$request->has('package_id') || !$request->has('characterstic_id')) {
            return response()->json([
                'success' => false,
                'message' => 'Missing package_id or characteristic_id',
                'data' => null,
            ], 400);
        }

        $packageId = $request->package_id;
        $characteristicId = $request->characterstic_id;

        $packageExists = Package::find($packageId);
        if (!$packageExists) {
            return response()->json([
                'success' => false,
                'message' => 'Safari Package not found.',
                'data' => null,
            ], 404);
        }

        // Delegate characteristic data fetching to repository
        $responseData = $this->packageRepository->getCharacteristicData($packageId, $characteristicId);

        if (empty($responseData) || (is_array($responseData) && empty($responseData))) {
            return response()->json([
                'success' => false,
                'message' => 'No data found for the given package_id and characteristic_id',
                'data' => null,
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Data found.',
            'data' => $responseData,
        ], 200);
    }

    /**
     * Create or add discussion to a package
     *
     * Note: This method remains in controller as it is write-related
     * and not purely query/read logic. Should eventually move to Service layer
     * for better transaction handling and business rule enforcement.
     */
    public function DiscussionData(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'package_id' => 'required|exists:packages,id',
            'content'    => 'required|string',
            'parentId'   => 'nullable|exists:safari_discussion,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->first(),
            ], 400);
        }

        $discussion = SafariDiscussion::create([
            'package_id' => $request->package_id,
            'user_id'    => Auth::id() ?? 1,
            'content'    => $request->content,
            'is_admin'   => 0,
            'parent_id'  => $request->parentId ?? null,
        ]);

        $discussions = SafariDiscussion::with(['user', 'admin'])
            ->where('package_id', $request->package_id)
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Discussion created successfully',
            'data' => $discussions,
        ], 201);
    }
}
