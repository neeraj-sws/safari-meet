<?php

namespace App\Queries\Filters;

use Illuminate\Database\Eloquent\Builder;

/**
 * PackageFilters encapsulates all filtering logic for Package queries.
 *
 * This class applies filters to a Package query builder based on request criteria.
 * Extracted from SafariPackageController to enable reuse and testability.
 */
class PackageFilters
{
    public function __construct(private Builder $query)
    {
    }

    /**
     * Apply state filter (join with park.state)
     */
    public function byState(?int $stateId): self
    {
        if ($stateId) {
            $this->query->whereHas('park.state', fn($q) => $q->where('id', $stateId));
        }
        return $this;
    }

    /**
     * Apply inclusion features filter
     */
    public function byInclusions(?array $featureIds): self
    {
        if ($featureIds && count($featureIds) > 0) {
            $this->query->whereHas('featuer_safaries', fn($q) => $q->whereIn('feature_id', $featureIds));
        }
        return $this;
    }

    /**
     * Apply park filter
     */
    public function byPark(?int $parkId): self
    {
        if ($parkId) {
            $this->query->where('park_id', $parkId);
        }
        return $this;
    }

    /**
     * Apply visit purpose (theme) filter
     */
    public function byTheme(?array $visitPurposeIds): self
    {
        if ($visitPurposeIds && count($visitPurposeIds) > 0) {
            $this->query->whereIn('visit_purpose_id', $visitPurposeIds);
        }
        return $this;
    }

    /**
     * Apply best time to visit filter
     */
    public function byBestTime(?array $bestTimeIds): self
    {
        if ($bestTimeIds && count($bestTimeIds) > 0) {
            $this->query->whereIn('best_time', $bestTimeIds);
        }
        return $this;
    }

    /**
     * Apply species filter (via park.wildlife.species)
     */
    public function bySpecies(?int $speciesId): self
    {
        if ($speciesId) {
            $parkIds = \App\Models\Park::whereHas('ParkSpecies',
                fn($q) => $q->where('species_id', $speciesId)
            )->pluck('id');
            $this->query->whereIn('park_id', $parkIds);
        }
        return $this;
    }

    /**
     * Apply stay category filter
     */
    public function byStayCategory(?array $stayCategories): self
    {
        if ($stayCategories && count($stayCategories) > 0) {
            $this->query->whereIn('stay_category_id', $stayCategories);
        }
        return $this;
    }

    /**
     * Apply price range filter (handles string casting)
     */
    public function byPriceRange(?float $minPrice = null, ?float $maxPrice = null): self
    {
        if (is_numeric($minPrice) && is_numeric($maxPrice)) {
            $this->query->whereRaw('CAST(min_price_pp AS UNSIGNED) <= ?', [$maxPrice])
                ->whereRaw('CAST(max_price_pp AS UNSIGNED) >= ?', [$minPrice]);
        }
        return $this;
    }

    /**
     * Apply number of days filter
     */
    public function byDayRange(?int $minDays = null, ?int $maxDays = null): self
    {
        if (is_numeric($minDays) && is_numeric($maxDays)) {
            $this->query->whereRaw('CAST(start_tour AS UNSIGNED) <= ?', [$maxDays])
                ->whereRaw('CAST(start_tour AS UNSIGNED) >= ?', [$minDays]);
        }
        return $this;
    }

    /**
     * Apply number of safaris filter
     */
    public function bySafariCount(?int $minSafari = null, ?int $maxSafari = null): self
    {
        if (is_numeric($minSafari) && is_numeric($maxSafari)) {
            $this->query->whereRaw('CAST(no_of_safari AS UNSIGNED) <= ?', [$maxSafari])
                ->whereRaw('CAST(no_of_safari AS UNSIGNED) >= ?', [$minSafari]);
        }
        return $this;
    }

    /**
     * Apply ordering (popular, latest, trending, top-rated)
     */
    public function orderBy(?string $sortBy = null): self
    {
        match ($sortBy) {
            'popular' => $this->query->orderBy('popular', 'DESC'),
            'latest' => $this->query->orderBy('created_at', 'DESC'),
            'trending' => $this->query->orderBy('trending', 'DESC'),
            'top' => $this->query->orderBy('top_rated', 'DESC'),
            default => $this->query->orderBy('created_at', 'DESC'),
        };
        return $this;
    }

    /**
     * Only return published packages
     */
    public function published(): self
    {
        $this->query->where('status', 1);
        return $this;
    }

    /**
     * Get the underlying query builder
     */
    public function build(): Builder
    {
        return $this->query;
    }
}
