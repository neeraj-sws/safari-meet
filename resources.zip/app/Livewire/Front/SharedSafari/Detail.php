<?php

namespace App\Livewire\Front\SharedSafari;

use App\Models\ShareSafari;
use App\Models\{Admin, FeaturePackageSafari, FeatureThingsToCarrySafari, ItineraryPackage, JoinSharedSafari, ParkFaq, ReportResion, SafariAllottedSeat, SafariConversation, SafariDiscussion, User, Wishlist};
use App\Services\SharedSafariDetailService;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\On;
use Livewire\WithPagination;

class Detail extends Component
{

    use WithPagination;

    public $shareSafari, $durationText, $similarPackages, $faqs, $carousel = true;
    public $dataInclusions, $dataExclusions, $dataAmenities = [], $itineraries = [], $thingsToCarries = [], $types, $organizer;
    public $discussions = [], $content, $replyBox, $dynamicTabs = [], $showUsersList = false, $userCountList = [];
    public $showChatBox = false, $joinededSafariSafri = 0, $conversation;
    public $allotSlot = false, $seat_number, $totalallottedSeats = [], $selectedUserId, $leavesharedSafariId;
    public $replyContent = [], $wishlistTitle = "Add Wishlist";
    public $reportDiscussionId;
    public $selectedResion;
    public $notes;
    public $reportResions = [];
    public $showReportModal = false, $type = 'user';
    private ?SharedSafariDetailService $detailService = null;

    private function service(): SharedSafariDetailService
    {
        if (!$this->detailService) {
            $this->detailService = app(SharedSafariDetailService::class);
        }

        return $this->detailService;
    }


    public function mount($slug)
    {
        $this->shareSafari = ShareSafari::with([
            'detailsTabs',
            'dynamicTabs',
            'park.state',
            'category',
            'safariTypes.types',
            'park.parkSafariTypes',
            'park.parkBestTimes.weather',
            'joinedsafari',
            'allottedSeat',
        ])->where('slug', $slug)->first();
        if (empty($this->shareSafari)) {
            return redirect()->route('error.landing');
        }
        $this->faqs = ParkFaq::where('park_id', $this->shareSafari->park->id)->get()->toArray();
        $this->types = $this->shareSafari->safariTypes->pluck('types.name')->filter()->implode(', ');
        $this->dynamicTabs = $this->shareSafari->dynamicTabs;
        if ($this->shareSafari->organized_type == 'user') {
            $this->organizer =   User::find($this->shareSafari->organized_by);
            $this->type = "user";
        } elseif ($this->shareSafari->organized_type == 'agent') {
            $this->organizer =   User::find($this->shareSafari->organized_by);
            $this->type = "user";
        } elseif ($this->shareSafari->organized_type == 'admin') {
            $this->organizer = Admin::find($this->shareSafari->organized_by);
            $this->type = "admin";
        }
        $allData = FeaturePackageSafari::where('share_safari_id', $this->shareSafari->id)
            ->get()
            ->toArray();
        $this->thingsToCarries = FeatureThingsToCarrySafari::where('share_safari_id', $this->shareSafari->id)
            ->get();

        $this->dataInclusions = array_filter($allData, function ($item) {
            return $item['type'] == 1;
        });

        $this->dataExclusions = array_filter($allData, function ($item) {
            return $item['type'] == 2;
        });
        $this->dataAmenities = array_filter($allData, function ($item) {
            return $item['type'] == 3;
        });

        $this->itineraries = ItineraryPackage::with('packageActivities')->where('share_safari_id', $this->shareSafari->id)->orderBy('order_by', 'asc')->get();
        $start = Carbon::parse($this->shareSafari->start_date);
        $end = Carbon::parse($this->shareSafari->end_date);
        $days = $start->diffInDays($end) + 1;
        $nights = $days - 1;
        $this->durationText = "{$nights} Nights / {$days} Days";
        $this->similarPackages = ShareSafari::with('park.state')->where('safari_park_id', $this->shareSafari->safari_park_id)->where('status', 1)->whereNot('slug', $slug)->get();
        $checkWishlist = Wishlist::where('shared_safari_id', $this->shareSafari->id)
            ->where('user_id', Auth::id())
            ->first();
        if ($checkWishlist) {
            $this->wishlistTitle = "Remove Wishlist";
        }
        $this->userListCount();
        $this->loadJoinSharedSafari();
        $this->allottedSetsUser();
    }
    #[Layout('components.layouts.guest')]
    public function render()
    {
        $interestedUsers = JoinSharedSafari::with('user')
            ->where('share_safari_id', $this->shareSafari->id)
            ->orderBy('updated_at', 'desc')
            ->latest()
            ->paginate(10);

        $this->loadDiscussions();

        return view('livewire.front.shared-safari.detail', compact('interestedUsers'));
    }

    private function loadDiscussions()
    {
        $this->discussions = SafariDiscussion::with(['user', 'admin', 'replies'])
            ->where('share_safari_id', $this->shareSafari->id)
            ->whereNull('parent_id')
            ->orderBy('created_at', 'asc')
            ->get();
    }

    public function discussionReplyBox($id)
    {
        $this->replyBox = $this->replyBox === $id ? null : $id;
    }

    public function save($parentId = null)
    {
        $field   = $parentId ? "replyContent.$parentId" : "content";
        $content = $parentId ? ($this->replyContent[$parentId] ?? '') : $this->content;

        $this->validate([
            $field => 'required|string|max:500',
        ], [
            "$field.required" => 'Please write something before posting.',
        ]);

        $urlPattern = '/\b((https?:\/\/)?(www\.)?[a-z0-9-]+(\.[a-z]{2,})(\/\S*)?)/i';

        if (preg_match($urlPattern, $content)) {
            return $this->dispatch('swal:toast', [
                'type' => 'error',
                'message' => 'You cannot share links, domains, or websites in your message.',
            ]);
            return back()->withErrors([
                $field => 'You cannot share links, domains, or websites in your message.',
            ]);
        }

        SafariDiscussion::create([
            'share_safari_id' => $this->shareSafari->id,
            'user_id'         => Auth::id() ?? 0,
            'content'         => $content,
            'is_admin'        => 0,
            'parent_id'       => $parentId,
        ]);


        if ($parentId) {
            unset($this->replyContent[$parentId]);
        } else {
            $this->content = '';
        }
        $this->replyBox = null;
        $this->loadDiscussions();

        $receiver_type = ($this->shareSafari->organized_type == 'admin') ? 'App\Models\Admin' : 'App\Models\User';
        createNotification(
            14,
            $this->shareSafari->organized_by,
            $receiver_type,
            Auth::guard('web')->id(),
            get_class(Auth::guard('web')->user()),
            [
                'user_name' => Auth::guard('web')->user()->name,
                'safari_id' =>  $this->shareSafari->id,
                'safari_name' =>  $this->shareSafari->title ?? null,
                'message' => Auth::guard('web')->user()->name . ' joined ' . $this->shareSafari->title . ' shared safari successfully.',
                'safari_url' => route('shared-safari.detail', ['slug' => $this->shareSafari->slug])
            ],
            'chat'
        );

        $this->dispatch('swal:toast', [
            'type' => 'success',
            'message' => 'Comment added successfully!',
        ]);
    }

    public function joinsafari($id)
    {
        $safari = ShareSafari::find($id);

        if (!$safari) {
            $this->dispatch('swal:toast', [
                'type' => 'error',
                'title' => '',
                'message' => "Something went wrong",
            ]);
            return;
        }

        $result = $this->service()->joinSafari($safari, Auth::guard('web')->id());

        $this->dispatch('swal:toast', [
            'type' => $result['success'] ? 'success' : 'error',
            'title' => '',
            'message' => $result['message'],
        ]);

        if ($result['success']) {
            $this->userListCount();
            $this->loadJoinSharedSafari();
        }
    }

    public function confirmdeletejoinsafari($id)
    {
        $this->leavesharedSafariId = $id;
        $this->dispatch('swal:confirm', [
            'title' => 'Are you sure?',
            'text' => 'You Want to Leave this shared safari',
            'icon' => 'warning',
            'showCancelButton' => true,
            'confirmButtonText' => 'Yes, Leave it!',
            'cancelButtonText' => 'Cancel',
            'action' => 'deletejoinsafari'
        ]);
    }

    #[On('deletejoinsafari')]
    public function deletejoinsafari()
    {
        $result = $this->service()->leaveSafari($this->shareSafari, $this->leavesharedSafariId, Auth::guard('web')->id());
        $this->showChatBox = false;

        $this->dispatch('swal:toast', [
            'type' => $result['success'] ? 'success' : 'error',
            'title' => '',
            'message' => $result['message'],
        ]);
        $this->leavesharedSafariId = "";
        $this->loadJoinSharedSafari();
        $this->userListCount();
    }

    public function showUserLists()
    {
        $this->showUsersList = true;
        $this->allottedSetsUser();
    }

    public function closeUserLists()
    {
        $this->showUsersList = false;
        $this->allotSlot = false;
        $this->dispatch('resetSocialMediaCount');
    }


    public function userListCount()
    {
        $this->userCountList = JoinSharedSafari::with('user')->where('share_safari_id', $this->shareSafari->id)->get();
    }

    private function loadJoinSharedSafari()
    {
        $this->joinededSafariSafri = JoinSharedSafari::where('user_id', Auth::guard('web')->id())
            ->where('share_safari_id', $this->shareSafari->id)
            ->first();

        if (!Auth::guard('web')->check()) {
            $this->conversation = null;
            return;
        }

        $this->conversation = SafariConversation::where('share_safari_id', $this->shareSafari->id)
            ->where('participant_id', Auth::guard('web')->id())
            ->first();
    }

    public function ShowChatBox()
    {
        $this->showChatBox = true;
    }

    public function showAllotSlot($userId)
    {
        $this->selectedUserId = $userId;
        $this->allotSlot = true;

        $seat = SafariAllottedSeat::where('user_id', $userId)
            ->where('shared_safari_id', $this->shareSafari->id)
            ->first();

        $this->seat_number = $seat->number_of_seat ?? null;
    }

    public function submitAllotedSeat($userId)
    {
        $result = $this->service()->allotSeat($this->shareSafari, $userId, (int) $this->seat_number);

        if (!$result['success']) {
            $this->dispatch('swal:toast', [
                'type' => 'error',
                'message' => $result['message'],
            ]);
            return;
        }

        $this->shareSafari->is_seat_full = !empty($result['is_seat_full']) ? 1 : 0;
        $this->shareSafari->save();

        $this->allottedSetsUser();
        $this->dispatch('swal:toast', [
            'type' => 'success',
            'message' => $result['message'],
        ]);

        $this->allotSlot = false;
        $this->selectedUserId = null;
        $this->seat_number = null;
    }


    public function allottedSetsUser()
    {
        $this->totalallottedSeats = SafariAllottedSeat::where('shared_safari_id', $this->shareSafari->id)->get();
    }

    public function deleteAllotedSeat($userId)
    {
        $result = $this->service()->deleteAllottedSeat($this->shareSafari, $userId);

        $this->dispatch('swal:toast', [
            'type' => $result['success'] ? 'success' : 'error',
            'title' => '',
            'message' => $result['message'],
        ]);

        if (!$result['success']) {
            return;
        }

        $this->shareSafari->is_seat_full = !empty($result['is_seat_full']) ? 1 : 0;
        $this->shareSafari->save();

        $this->allottedSetsUser();

        $this->allotSlot = false;
        $this->selectedUserId = null;
        $this->seat_number = null;
    }

    public function addwishlist($id)
    {
        $result = $this->service()->toggleWishlist($this->shareSafari, Auth::id());

        if ($result['success']) {
            $this->wishlistTitle = $result['title'];
        }

        return $this->dispatch('swal:toast', [
            'type' => $result['success'] ? 'success' : 'error',
            'title' => '',
            'message' => $result['message'],
        ]);
    }

    public function discussionReport($discussionId)
    {
        $this->reportDiscussionId = $discussionId;
        $this->reportResions = ReportResion::where('status', '1')->get();
        $this->selectedResion = null;
        $this->notes = '';
        $this->showReportModal = true;
    }

    public function submitReport()
    {
        $this->validate([
            'selectedResion' => 'required|exists:report_resions,report_resion_id',
            'notes' => 'nullable|string|max:500',
        ]);
        $result = $this->service()->reportDiscussion(
            $this->shareSafari,
            $this->reportDiscussionId,
            $this->selectedResion,
            $this->notes,
            Auth::id()
        );

        if ($result['success']) {
            $this->reset(['showReportModal', 'selectedResion', 'notes', 'reportDiscussionId']);
        }

        $this->dispatch('swal:toast', [
            'type' => $result['success'] ? 'success' : 'error',
            'title' => '',
            'message' => $result['message'],
        ]);
    }
}
