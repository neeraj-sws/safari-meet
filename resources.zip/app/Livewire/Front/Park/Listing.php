<?php

namespace App\Livewire\Front\Park;

use App\Helpers\UserHelper;
use App\Models\Park;
use App\Models\ParkBestTimeModel;
use App\Models\ParkSpecies;
use App\Models\State;
use App\Models\ShareSafari;
use App\Models\StayCategory;
use App\Models\WeatherModel;
use App\Services\ParkListingService;
use Livewire\Component;
use Livewire\Attributes\Layout;

class Listing  extends Component
{

    public $parks, $states, $species, $stayCategory, $park_datas, $shareSafaris, $BestTimesVisits;
    public $stateSelect = null, $speciesSelect = null, $parkSelect = null, $stayCategorySelect = null, $bestTimeSelect = [], $allFiltersValue = [];
    public $perPage = 6, $seoContents, $orderbyfilter;

    public function mount(ParkListingService $service)
    {
        $options = $service->resolveFilterOptions();

        $this->states = $options['states'];
        $this->species = $options['species'];
        $this->BestTimesVisits = $options['bestTimesVisits'];
        $this->stayCategory = $options['stayCategory'];
        $this->park_datas = $options['park_datas'];

        $this->seoContents  = UserHelper::SeoDetails('park');
    }

    public function loadMore()
    {
        $this->perPage += 3;
    }


    #[Layout('components.layouts.guest')]
    public function render(ParkListingService $service)
    {
        $this->parks = $service->getFilteredParks([
            'stateSelect' => $this->stateSelect,
            'speciesSelect' => $this->speciesSelect,
            'parkSelect' => $this->parkSelect,
            'stayCategorySelect' => $this->stayCategorySelect,
            'bestTimeSelect' => $this->bestTimeSelect,
            'orderbyfilter' => $this->orderbyfilter,
        ], $this->perPage);

        return view('livewire.front.park.list')->layoutData([
            'seoContents' => $this->seoContents,
        ]);
    }

    public function firstTimeLoading(){

    }

    public function updatedStateSelect(ParkListingService $service)
    {
        $name = $service->resolveFilterDisplayName('state', $this->stateSelect);
        if ($name) {
            $this->allFiltersValue['state'] = $name;
        }
    }

    public function updatedSpeciesSelect(ParkListingService $service)
    {
        $name = $service->resolveFilterDisplayName('species', $this->speciesSelect);
        if ($name) {
            $this->allFiltersValue['species'] = $name;
        }
    }

    public function updatedParkSelect(ParkListingService $service)
    {
        $name = $service->resolveFilterDisplayName('park', $this->parkSelect);
        if ($name) {
            $this->allFiltersValue['park'] = $name;
        }
    }

    public function updatedBestTimeSelect(ParkListingService $service)
    {
        $titles = $service->resolveFilterDisplayName('best_time', $this->bestTimeSelect);
        if ($titles) {
            $this->allFiltersValue['best_time'] = $titles;
        }
    }


    public function clearAll()
    {
        $this->reset([
            'stateSelect',
            'speciesSelect',
            'parkSelect',
            'stayCategorySelect',
            'bestTimeSelect',
            'allFiltersValue',
            'orderbyfilter',
        ]);

        // $this->dispatch('filtersCleared');
    }

    public function removeFilter($filterKey)
    {
        switch ($filterKey) {
            case 'state':
                $this->reset('stateSelect');
                break;
            case 'species':
                $this->reset('speciesSelect');
                break;
            case 'park':
                $this->reset('parkSelect');
                break;
            case 'best_time':
                $this->reset('bestTimeSelect');
                break;
            case 'orderby':
                $this->orderbyfilter = null;
                break;
        }

        unset($this->allFiltersValue[$filterKey]);
    }

    public function removeFilterValue($filterKey, $value)
    {
        if ($filterKey === 'best_time') {
            $this->allFiltersValue['best_time'] = array_filter(
                $this->allFiltersValue['best_time'],
                fn($item) => $item !== $value
            );

            $weather = WeatherModel::where('title', $value)->first();
            if ($weather) {
                $this->bestTimeSelect = array_diff($this->bestTimeSelect, [$weather->id]);
            }

            if (empty($this->allFiltersValue['best_time'])) {
                unset($this->allFiltersValue['best_time']);
            }
        }
    }

    public function updatedOrderbyfilter()
    {

        switch ($this->orderbyfilter) {
            case 'popular':
                $this->allFiltersValue['orderby'] = 'Popular';
                break;
            case 'latest':
                $this->allFiltersValue['orderby'] = 'Latest';
                break;
            case 'trending':
                $this->allFiltersValue['orderby'] = 'Trending';
                break;
            case 'top':
                $this->allFiltersValue['orderby'] = 'Top Rated';
                break;
            default:
                $this->allFiltersValue['orderby'] = 'All';
                $this->orderbyfilter = null;
                break;
            case 'orderby':
                $this->orderbyfilter = null;
                break;
        }
    }
}
