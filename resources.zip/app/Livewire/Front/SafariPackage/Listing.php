<?php

namespace App\Livewire\Front\SafariPackage;

use Livewire\Component;
use App\Models\{
    Feature,
    State,
    Park,
    Species,
    StayCategory,
    VisitPurpose,
    WeatherModel
};
use Livewire\Attributes\Layout;
use Livewire\Attributes\Computed;
use Illuminate\Support\Facades\Cache;
use App\Helpers\UserHelper;
use App\Services\SafariPackageListingService;

class Listing extends Component
{
    public $park_datas;
    public $stateSelect, $parkSelect, $speciesSelected;
    public $bttv_selected = [], $selectedStayCategories = [], $inclusion_select = [], $theme_select = [];
    public $minPrice, $maxPrice, $minday, $maxday, $minSafari, $maxSafari, $heroSecion = true, $allFiltersValue = [], $carousel;
    public $perPage = 12, $orderbyfilter, $page = 1;
    public $seoContents;
    private ?SafariPackageListingService $listingService = null;

    protected $listeners = ['filtersUpdated' => 'applyFilters'];

    public function mount($carousel = null, $type = null, $species = null)
    {
        if ($carousel == 1) {
            $this->heroSecion = false;
        }

        if (!empty($species)) {
            if ($type == 1) {
                $this->speciesSelected = $species->id;
                $this->allFiltersValue['species'] = $species->name;
            } else if ($type == 2) {
                $this->parkSelect = $species->id;
                $this->allFiltersValue['park'] = $species->name;
            }
        }

        $this->park_datas = Park::select('park_id', 'name', 'slug', 'display_image')->take(12)->get();
        $this->page = 1;
        $this->seoContents = Cache::remember('safari-packages', 1440, function () {
            return UserHelper::SeoDetails('safari-packages');
        });
    }

    public function loadsafarisMore()
    {
        $this->page += 1;
    }

    #[Computed]
    public function packages()
    {
        return $this->service()->listPackages(
            $this->currentFilters(),
            $this->perPage,
            $this->page,
            $this->orderbyfilter
        );
    }

    #[Layout('components.layouts.guest')]
    public function render()
    {
        // dd($this->packages);
        return view('livewire.front.safari-package.list', [
            'packages' => $this->packages,
        ])->layoutData([
                    'seoContents' => $this->seoContents,
                ]);
    }

    public function loadPackages()
    {
        // empty bhi reh sakta hai
    }


    public function applyFilters($filters)
    {
        // dd($filters);
        $this->resetFilters();
        $resolved = $this->service()->resolveFilters($filters);

        $this->stateSelect = $resolved['stateSelect'];
        $this->parkSelect = $resolved['parkSelect'];
        $this->speciesSelected = $resolved['speciesSelected'];
        $this->bttv_selected = $resolved['bttv_selected'];
        $this->selectedStayCategories = $resolved['selectedStayCategories'];
        $this->inclusion_select = $resolved['inclusion_select'];
        $this->theme_select = $resolved['theme_select'];
        $this->minPrice = $resolved['minPrice'];
        $this->maxPrice = $resolved['maxPrice'];
        $this->minday = $resolved['minday'];
        $this->maxday = $resolved['maxday'];
        $this->minSafari = $resolved['minSafari'];
        $this->maxSafari = $resolved['maxSafari'];
        $this->allFiltersValue = $resolved['allFiltersValue'];
    }

    public function removeFilter($key)
    {
        unset($this->allFiltersValue[$key]);

        switch ($key) {
            case 'state':
                $this->stateSelect = null;
                break;
            case 'park':
                $this->parkSelect = null;
                break;
            case 'species':
                $this->speciesSelected = null;
                break;
            case 'best_time':
                $this->bttv_selected = [];
                break;
            case 'stay_category':
                $this->selectedStayCategories = [];
                break;
            case 'inclusion':
                $this->inclusion_select = [];
                break;
            case 'visit_purpose':
                $this->theme_select = [];
                break;
            case 'price':
                $this->minPrice = $this->maxPrice = null;
                break;
            case 'days':
                $this->minday = $this->maxday = null;
                break;
            case 'safari':
                $this->minSafari = $this->maxSafari = null;
                break;
            case 'orderby':
                $this->orderbyfilter = null;
                break;
        }

        $this->dispatch('sidebarRemoveFilter', $key);
    }

    public function removeFilterValue($key, $value)
    {
        // dd($key, $value);
        if (isset($this->allFiltersValue[$key]) && is_array($this->allFiltersValue[$key])) {
            $this->allFiltersValue[$key] = array_filter(
                $this->allFiltersValue[$key],
                fn($item) => trim($item) !== trim($value)
            );

            if (empty($this->allFiltersValue[$key])) {
                unset($this->allFiltersValue[$key]);
            }

            if ($key === 'stay_category') {
                $this->selectedStayCategories = [];
                if (!empty($this->allFiltersValue[$key])) {
                    $this->selectedStayCategories = StayCategory::whereIn('name', $this->allFiltersValue[$key])
                        ->pluck('stay_category_id')->toArray();
                }
            } else if ($key === 'inclusion') {
                $this->inclusion_select = [];
                if (!empty($this->allFiltersValue[$key])) {
                    $this->inclusion_select = Feature::whereIn('title', $this->allFiltersValue[$key])->pluck('features_id')->toArray();
                }
            } else if ($key === 'visit_purpose') {
                $this->theme_select = [];
                if (!empty($this->allFiltersValue[$key])) {
                    $this->theme_select = VisitPurpose::whereIn('name', $this->allFiltersValue[$key])->pluck('visit_purpose_id')->toArray();
                }
            } else if ($key === "best_time") {
                $this->bttv_selected = [];
                if (!empty($this->allFiltersValue[$key])) {
                    $this->bttv_selected = WeatherModel::whereIn('title', $this->allFiltersValue[$key])->pluck('park_weather_id')->toArray();
                }
            }
        }

        $this->dispatch('sidebarRemoveFilter', $key, $value);
    }

    public function clearAll()
    {
        $this->resetFilters();
        $this->allFiltersValue = [];
        $this->dispatch('sidebarClearAll');
    }

    private function resetFilters()
    {
        $this->reset([
            'stateSelect',
            'parkSelect',
            'speciesSelected',
            'bttv_selected',
            'selectedStayCategories',
            'inclusion_select',
            'theme_select',
            'minPrice',
            'maxPrice',
            'minday',
            'maxday',
            'minSafari',
            'maxSafari',
            'orderbyfilter',
        ]);
    }

    public function updatedOrderbyfilter()
    {

        switch ($this->orderbyfilter) {
            case 'popular':
                $this->allFiltersValue['orderby'] = 'Popular';
                break;
            case 'latest':
                $this->allFiltersValue['orderby'] = 'Latest';
                break;
            case 'trending':
                $this->allFiltersValue['orderby'] = 'Trending';
                break;
            case 'top':
                $this->allFiltersValue['orderby'] = 'Top Rated';
                break;
            default:
                $this->allFiltersValue['orderby'] = 'All';
                $this->orderbyfilter = null;
                break;
        }
    }

    private function service(): SafariPackageListingService
    {
        if (!$this->listingService) {
            $this->listingService = app(SafariPackageListingService::class);
        }

        return $this->listingService;
    }

    private function currentFilters(): array
    {
        return [
            'stateSelect' => $this->stateSelect,
            'parkSelect' => $this->parkSelect,
            'speciesSelected' => $this->speciesSelected,
            'bttv_selected' => $this->bttv_selected,
            'selectedStayCategories' => $this->selectedStayCategories,
            'inclusion_select' => $this->inclusion_select,
            'theme_select' => $this->theme_select,
            'minPrice' => $this->minPrice,
            'maxPrice' => $this->maxPrice,
            'minday' => $this->minday,
            'maxday' => $this->maxday,
            'minSafari' => $this->minSafari,
            'maxSafari' => $this->maxSafari,
        ];
    }
}
