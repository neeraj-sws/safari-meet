<?php

namespace App\Livewire\Admin\Common;

use App\Models\FeatureThingsToCarrySafari;
use App\Models\Package;
use App\Models\ShareSafari;
use App\Models\ThingsToCarry as ModelsThingsToCarry;
use App\Services\AdminCommonContentService;
use Livewire\Component;
use Livewire\Attributes\On;

class ThingsToCarry extends Component
{
    public $modelTable, $type;
    public $thingsToCarries = [], $thingsToCarryList = [], $formItems = [], $featurethingstocarry, $deleteId;
    public $showForm = false;

    public function mount($type = null, $id = null, AdminCommonContentService $service)
    {
        $this->modelTable = $service->resolveModel($type, $id);
        $this->type = $type;
        $this->thingsToCarries = $service->getThingsToCarryOptions();
    }

    public function render(AdminCommonContentService $service)
    {
        $this->thingsToCarryList = $service->getThingsToCarryList($this->type, $this->modelTable->id);
        return view('livewire.admin.common.things-to-carry');
    }

    public function toggleForm()
    {
        $this->showForm = !$this->showForm;
        if ($this->showForm) $this->resetForm();
    }

    public function resetForm()
    {
        $this->reset(['formItems', 'featurethingstocarry', 'deleteId']);
        $this->resetValidation();
    }

    public function updatedFeaturethingstocarry($id, AdminCommonContentService $service)
    {
        if (!$id) return;

        $data = $service->getThingToCarryDetails($id);
        if (!$data) return;

        $this->formItems[] = [
            'title'       => $data->title,
            'description' => $data->short_description,
        ];
        $this->featurethingstocarry = null;
    }


    public function addFormItem()
    {
        $this->formItems[] = ['title' => '', 'description' => ''];
    }

    public function removeFormItem($i)
    {
        unset($this->formItems[$i]);
        $this->formItems = array_values($this->formItems);
    }

    public function store(AdminCommonContentService $service)
    {

        if (empty($this->formItems)) {
            $this->validate([
                'featurethingstocarry' => 'required|exists:things_to_carries,things_to_carry_id',
            ], [
                'featurethingstocarry.required' => 'Please select a "Thing to Carry".',
            ]);

        } else {

            $this->validate([
                'formItems.*.title'       => 'required|string',
                'formItems.*.description' => 'required|string',
            ], [
                'formItems.*.title.required'       => 'Title is required.',
                'formItems.*.description.required' => 'Description is required.',
            ]);
        }

        // Save items via service
        $service->storeThingsToCarry($this->type, $this->modelTable->id, $this->formItems);

        $this->toggleForm();
        $this->dispatch('swal:toast', [
            'type' => 'success',
            'message' => 'Things to carry saved successfully.'
        ]);
    }


    public function confirmDelete($id)
    {
        $this->deleteId = $id;
        $this->dispatch('swal:confirm', [
            'title' => 'Are you sure?',
            'text' => 'This action cannot be undone.',
            'icon' => 'warning',
            'showCancelButton' => true,
           'confirmButtonText' => 'Yes, delete it!',
            'action' => 'deleteConfirmed'
        ]);
    }

    #[On('deleteConfirmed')]
    public function delete(AdminCommonContentService $service)
    {
        $service->deleteThingToCarry($this->deleteId);
        $this->dispatch('swal:toast', [
            'type' => 'success',
            'message' => 'Deleted successfully.'
        ]);
    }
}
