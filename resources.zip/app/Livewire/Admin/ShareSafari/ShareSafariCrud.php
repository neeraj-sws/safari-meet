<?php

namespace App\Livewire\Admin\ShareSafari;

use App\Helpers\ImageHelper;
use App\Models\{JoinSharedSafari, SpeciesCategory, Park, ShareSafari, StayCategory, Upload, VisitPurpose};
use App\Services\AdminSharedSafariListingService;
use App\Services\Workflows\SafariCreationWorkflow;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\{Layout, On};
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\Features\SupportFileUploads\WithFileUploads;
use Livewire\WithPagination;

#[Layout('components.layouts.admin-app')]
class ShareSafariCrud extends Component
{
    use WithFileUploads;
    use WithPagination;
    public $showModal = false, $isEditing = false, $editId, $deleteId;
    public $modalTitle = 'Add', $pageTitle = 'Shared Safari';
    public $search = '';
    public $step = 1;

    public $title, $safariPark, $day, $night, $safari_no = 1;
    public $visit_purpose_id, $stay_category_id, $min_price_pp, $max_price_pp, $total_seats, $share_seats;
    public $safari_plan, $display_image, $previousImage;
    public $safariParks, $visitPurposes, $stayCategories;
    public $filter_park, $filter_visitPurposes, $filter_stayCategories;
    public $filter_park_temp, $filter_visitPurposes_temp, $filter_stayCategories_temp, $details, $ids;
    public $uploaded_images = [], $best_month_start, $best_month_end, $category, $categories = [], $activeState = 1, $userCount, $adminCount, $agentCount;

    public function mount()
    {
        $this->safariParks = Park::pluck('name', 'park_id');
        $this->visitPurposes = VisitPurpose::pluck('name', 'visit_purpose_id');
        $this->stayCategories = StayCategory::pluck('name', 'stay_category_id');
        $this->categories = SpeciesCategory::pluck('name', 'species_category_id');
        $activeTabName = request()->query('tab');
        if (!empty($activeTabName)) {
            if ($activeTabName == 'admin') {
                $this->activeState = 1;
            } elseif ($activeTabName == 'user') {
                $this->activeState = 2;
            } elseif ($activeTabName == 'agent') {
                $this->activeState = 3;
            }
        }
    }
    public function render(AdminSharedSafariListingService $service)
    {
        $counts = $service->getOrganizerCounts();
        $this->userCount = $counts['userCount'];
        $this->adminCount = $counts['adminCount'];
        $this->agentCount = $counts['agentCount'];

        $shareSafaries = $service->getFilteredSafaris([
            'search' => $this->search,
            'activeState' => $this->activeState,
            'filter_park' => $this->filter_park_temp,
            'filter_visitPurposes' => $this->filter_visitPurposes_temp,
            'filter_stayCategories' => $this->filter_stayCategories_temp,
        ], 10);

        return view('livewire.admin.share-safari.index', compact('shareSafaries'));
    }
    public function applyFilter()
    {
        $this->filter_park_temp = $this->filter_park;
        $this->filter_visitPurposes_temp = $this->filter_visitPurposes;
        $this->filter_stayCategories_temp = $this->filter_stayCategories;
    }
    public function resetFilter()
    {
        $this->reset(['search', 'filter_park', 'filter_visitPurposes', 'filter_stayCategories', 'filter_park_temp', 'filter_visitPurposes_temp', 'filter_stayCategories_temp']);
    }

    public function detail($id, SafariCreationWorkflow $workflow)
    {
        $safari = ShareSafari::find($id);

        if (!$safari) {
            $this->dispatch('swal:toast', [
                'type' => 'error',
                'title' => 'Error',
                'message' => 'Safari not found!'
            ]);
            return;
        }

        $this->ids = $id;
        $this->details = 1;
    }

    public function markSafariComplete($id, SafariCreationWorkflow $workflow)
    {
        $safari = ShareSafari::find($id);

        if (!$safari) {
            $this->dispatch('swal:toast', [
                'type' => 'error',
                'message' => 'Safari not found!'
            ]);
            return;
        }

        if (!$workflow->areDetailsComplete($safari)) {
            $checklist = $workflow->getDetailsChecklist($safari);
            $missing = collect($checklist)->filter(fn($v) => !$v)->keys()->implode(', ');

            $this->dispatch('swal:toast', [
                'type' => 'warning',
                'title' => 'Incomplete Details',
                'message' => "Please complete: $missing"
            ]);
            return;
        }

        if ($workflow->markAsComplete($safari)) {
            $this->dispatch('swal:toast', [
                'type' => 'success',
                'title' => 'Success',
                'message' => 'Safari creation completed! Admin will review soon.'
            ]);
        }
    }


    public function confirmDelete($id)
    {
        $this->deleteId = $id;
        $this->dispatch('swal:confirm', [
            'title' => 'Are you sure?',
            'text' => 'This action cannot be undone.',
            'icon' => 'warning',
            'showCancelButton' => true,
            'confirmButtonText' => 'Yes, delete it!',
            'cancelButtonText' => 'Cancel',
            'action' => 'delete'
        ]);
    }

    #[On('delete')]
    public function delete(AdminSharedSafariListingService $service)
    {
        $service->deleteSafari($this->deleteId);
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => $this->pageTitle . ' deleted successfully!']);
    }
    public function updating()
    {
        $this->resetPage();
    }


    public function removeDisplayImage(): void
    {
        if ($this->display_image) {
            $this->display_image->delete();
        }
        $this->display_image = null;
    }


    public function toggleStatus($id, AdminSharedSafariListingService $service)
    {
        $service->toggleStatus($id, 'status');
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }

    public function toggleStatusPopular($id, AdminSharedSafariListingService $service)
    {
        $service->toggleStatus($id, 'popular');
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }

    public function toggleStatusTrending($id, AdminSharedSafariListingService $service)
    {
        $service->toggleStatus($id, 'trending');
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }
    public function toggleStatusTopRated($id, AdminSharedSafariListingService $service)
    {
        $service->toggleStatus($id, 'top_rated');
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }

    public function publishedStatus($id, $status, AdminSharedSafariListingService $service)
    {
        $service->updateApprovalStatus($id, $status);
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }
}
