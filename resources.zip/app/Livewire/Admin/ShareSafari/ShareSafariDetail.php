<?php

namespace App\Livewire\Admin\ShareSafari;

use App\Helpers\ImageHelper;
use App\Models\{Park, ShareSafari, SharedSafariDetailsTabs, SharedShafariTabs};
use App\Services\AdminSharedSafariDetailService;
use Livewire\Attributes\{Layout, On};
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;

#[Layout('components.layouts.admin-app')]
class ShareSafariDetail extends Component
{
    public $showModal = false, $isEditing = false, $editId, $safariPark, $details;
    public $modalTitle = 'Add', $pageTitle = 'Share Safari Detail', $shareSafari, $safariParksId, $safariParks = [];
    public $characterstics = [], $characterDetailsData = [], $detailsMap = [], $showNavTab, $hasActiveData;

    public function mount($uuid, AdminSharedSafariDetailService $service)
    {
        $this->shareSafari = $service->getSafariByUuid($uuid);
        $this->safariParksId = $this->shareSafari->id;
        $this->safariParks = Park::pluck('name', 'park_id');

        // Service returns Collection, but Livewire serializes it to array
        $characteristics = $service->getCharacteristics();
        $this->characterstics = $characteristics->toArray();

        $this->characterDetailsData = SharedSafariDetailsTabs::where('shared_safari_id', $this->shareSafari->id)->get();
        $this->detailsMap = $service->getCharacteristicDetailData($this->shareSafari->id);

        $activeTabName = request()->query('tab');
        $activeTab = $service->resolveActiveTab($characteristics, $activeTabName);
        $this->showNavTab = $activeTab ? $activeTab->toArray() : null;

        if ($this->showNavTab && !isset($this->detailsMap[$this->showNavTab['shared_shafari_tabs_id']])) {
            $service->ensureCharacteristicDetail(
                $this->showNavTab['shared_shafari_tabs_id'],
                $this->shareSafari->id,
                $this->showNavTab['title']
            );

            $this->characterDetailsData = SharedSafariDetailsTabs::where('shared_safari_id', $this->shareSafari->id)->get();
            $this->detailsMap = $service->getCharacteristicDetailData($this->shareSafari->id);
        }

        $this->hasActiveData = $this->showNavTab ? ($this->detailsMap[$this->showNavTab['shared_shafari_tabs_id']] ?? null) : null;
        $this->safariPark = $this->shareSafari->safari_park_id;
    }

    public function render()
    {
        return view('livewire.admin.share-safari.detail');
    }

    public function toggleStatus($id, AdminSharedSafariDetailService $service)
    {
        $foundCharacteristic = collect($this->characterstics)->firstWhere('shared_shafari_tabs_id', $id);
        $this->showNavTab = $foundCharacteristic ?? null;

        $detail = $service->getOrCreateCharacteristicDetail($id, $this->shareSafari->id, $this->detailsMap);

        if ($detail) {
            $this->detailsMap[$id] = $detail;
            $this->hasActiveData = $detail;
        } else {
            $this->hasActiveData = null;
        }
    }

    #[On('package-status-updated')]
    public function refreshStatus($id)
    {
        $updatedDetail = SharedSafariDetailsTabs::find($id);

        if ($updatedDetail) {
            $this->detailsMap[$updatedDetail->shared_safari_tabs_id] = $updatedDetail->toArray();
            $this->characterDetailsData = SharedSafariDetailsTabs::where('shared_safari_id', $this->shareSafari->id)->get();
        }
    }
}
