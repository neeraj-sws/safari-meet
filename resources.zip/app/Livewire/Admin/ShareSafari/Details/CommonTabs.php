<?php

namespace App\Livewire\Admin\ShareSafari\Details;

use App\Models\PackageDetailsTabs;
use App\Models\PackageTabs;
use App\Models\SafariDetailsDynamicTabs;
use App\Models\SharedSafariDetailsTabs;
use App\Models\SharedShafariTabs;
use App\Services\AdminSharedSafariDetailTabService;
use Livewire\Component;

class CommonTabs extends Component
{
    public $characterDetails, $package, $activeTabe, $pageTitle, $short_description, $existingFact, $type, $column, $column2;

    public function mount($package, $type, $characterstic, AdminSharedSafariDetailTabService $service)
    {
        $this->package = $package;
        $this->characterDetails = $characterstic;
        $this->type = $type;
        $this->activeTabe = 'discussion';

        $this->pageTitle = $service->getTabTitle($this->type, $this->characterDetails);
        $this->column = ($this->type == 1) ? 'shared_safari_id' : 'package_id';
        $this->column2 = ($this->type == 1) ? 'shared_shafari_details_tabs_id' : 'package_details_tabs_id';
        $this->existingFact = $service->getExistingDynamicTab($this->type, $this->package, $this->characterDetails);

        if ($this->existingFact) {
            $this->short_description = $this->existingFact->short_description;
        }
    }

    public function render()
    {
        return view('livewire.admin.share-safari.details.common-tabs');
    }

    public function store(AdminSharedSafariDetailTabService $service)
    {
        $this->validate([
            'short_description' => 'required',
        ], [
            'short_description.required' => 'The Short Description field is required.',
        ]);

        $this->existingFact = $service->storeDynamicTabContent(
            $this->type,
            $this->package,
            $this->characterDetails,
            $this->short_description,
            $this->existingFact
        );

        $this->resetValidation();
        $this->dispatch('swal:toast', [
            'type' => 'success',
            'title' => '',
            'message' => $this->pageTitle . ' saved successfully.'
        ]);
    }

    public function changeTab() {}


    public function toggleStatus($id, AdminSharedSafariDetailTabService $service)
    {
        $detailTabs = $service->toggleDetailTabStatus($id);
        $this->dispatch('package-status-updated', id: $detailTabs->id);
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }
}
