<?php

namespace App\Livewire\Admin\ShareSafari\Details;

use App\Models\SharedSafariDetailsTabs;
use App\Services\AdminSharedSafariDetailTabService;
use Livewire\Component;

class FAQComponent extends Component
{

    public $characterDetails, $package, $activeTabe;

    public function mount($package = null, $characterstic = null)
    {
        $this->package = $package;
        $this->characterDetails = $characterstic;
        $this->activeTabe = 'faq';
    }

    public function render()
    {
        return view('livewire.admin.share-safari.details.f-a-q-component');
    }

    public function changeTab() {}


    public function toggleStatus($id, AdminSharedSafariDetailTabService $service)
    {
        $detailTabs = $service->toggleDetailTabStatus($id);
        $this->dispatch('package-status-updated', id: $detailTabs->id);
        $this->dispatch('swal:toast', ['type' => 'success', 'title' => '', 'message' => 'Status Changed Successfully']);
    }
}
