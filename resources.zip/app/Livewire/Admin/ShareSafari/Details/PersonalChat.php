<?php

namespace App\Livewire\Admin\ShareSafari\Details;

use App\Models\ShareSafari;
use Illuminate\Support\Facades\Auth;
use App\Models\{Admin, SafariConversation, SafariConversationMessage, User};
use App\Services\AdminSharedSafariDetailTabService;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.admin-app')]
class PersonalChat extends Component
{
    public $characterDetails, $sharedsafari;
    public $conversationId = null;
    public $chatConversationMessage;
    public $chatContent;
    public $shareSafari;
    public $selectedUser = null;
    public $safariConversations, $creator, $participant, $admin = false, $guard,$currentAuth,$pageTitle ="Persnal Chat";


    public function mount($uuid, AdminSharedSafariDetailTabService $service)
    {
        $this->shareSafari = ShareSafari::with(['park'])->where('uuid', $uuid)->first();
        $this->creator = true;  // true/false/null
        $this->currentAuth = Auth::guard('admin')->user();
        $this->loadConversations($service);
        $this->chatConversationMessage = collect();
    }

    public function render(AdminSharedSafariDetailTabService $service)
    {
        if ($this->conversationId) {
            $this->loadChatMessage($service);
        }
        return view('livewire.admin.share-safari.details.personal-chat');
    }

    /**
     * Load all conversations for the logged-in user
     */
    private function loadConversations(AdminSharedSafariDetailTabService $service)
    {
        if ($this->creator) {
            $this->safariConversations = $service->loadAdminConversations(
                Auth::guard('admin')->user()->id,
                $this->shareSafari->id
            );
        }
    }

    /**
     * Load messages of current conversation
     */
    private function loadChatMessage(AdminSharedSafariDetailTabService $service)
    {
        $this->chatConversationMessage = $service->loadChatMessages($this->conversationId);
    }

    /**
     * Select or start a conversation with a user
     */
    public function selectConversation($userId, AdminSharedSafariDetailTabService $service)
    {
        $this->selectedUser = User::find($userId);

        $conversation = $service->getOrCreateConversation(
            $this->currentAuth->id,
            get_class(Auth::guard('admin')->user()),
            $userId,
            get_class($this->selectedUser),
            $this->shareSafari->id,
            $this->shareSafari->organized_type
        );

        $this->conversationId = $conversation->id;
        $this->loadChatMessage($service);
        $this->loadConversations($service); // refresh sidebar
    }

    /**
     * Send message
     */
    public function saveChate(AdminSharedSafariDetailTabService $service)
    {
        $this->validate([
            'chatContent' => 'required|string|max:500',
        ]);

        if (!$this->conversationId) return;

        $service->sendChatMessage(
            $this->conversationId,
            $this->currentAuth->id,
            get_class($this->currentAuth),
            $this->chatContent
        );

        // broadcast
        // event(new MessageSent($message));

        $this->reset('chatContent');
        $this->loadChatMessage($service);
        $this->loadConversations($service);
    }
}
