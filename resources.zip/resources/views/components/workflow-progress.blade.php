@props(['step', 'progress', 'totalSteps' => 3, 'statusMessage' => ''])

<div class="workflow-progress-container mb-4">
    <!-- Step Indicators -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                @for ($i = 1; $i <= $totalSteps; $i++)
                    <div class="step-indicator {{ $i <= $step ? 'active' : '' }} {{ $i < $step ? 'completed' : '' }}">
                        <div class="step-circle">
                            @if ($i < $step)
                                <i class="fas fa-check text-white"></i>
                            @else
                                <span class="step-number">{{ $i }}</span>
                            @endif
                        </div>
                        <div class="step-label">
                            @switch($i)
                                @case(1)
                                    Basic Info
                                    @break
                                @case(2)
                                    Details
                                    @break
                                @case(3)
                                    Complete
                                    @break
                            @endswitch
                        </div>
                    </div>
                    @if ($i < $totalSteps)
                        <div class="step-connector {{ $i < $step ? 'completed' : '' }}"></div>
                    @endif
                @endfor
            </div>
        </div>
    </div>

    <!-- Progress Bar -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="progress" style="height: 25px;">
                <div class="progress-bar bg-success" role="progressbar" style="width: {{ $progress }}%"
                    aria-valuenow="{{ $progress }}" aria-valuemin="0" aria-valuemax="100">
                    {{ $progress }}%
                </div>
            </div>
        </div>
    </div>

    <!-- Status Message -->
    @if ($statusMessage)
        <div class="row">
            <div class="col-12">
                <div class="alert alert-info mb-0" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    {{ $statusMessage }}
                </div>
            </div>
        </div>
    @endif
</div>

<style>
    .workflow-progress-container {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        border-left: 4px solid #0066cc;
    }

    .step-indicator {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex: 1;
    }

    .step-circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #e9ecef;
        border: 2px solid #dee2e6;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: #495057;
        margin-bottom: 8px;
        transition: all 0.3s ease;
    }

    .step-indicator.active .step-circle {
        background: #0066cc;
        border-color: #0066cc;
        color: white;
        box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
    }

    .step-indicator.completed .step-circle {
        background: #28a745;
        border-color: #28a745;
        color: white;
    }

    .step-label {
        font-size: 12px;
        font-weight: 600;
        color: #495057;
        text-align: center;
    }

    .step-indicator.active .step-label {
        color: #0066cc;
        font-weight: 700;
    }

    .step-connector {
        flex: 0.5;
        height: 2px;
        background: #dee2e6;
        margin: 24px 0;
        transition: all 0.3s ease;
    }

    .step-connector.completed {
        background: #28a745;
    }

    @media (max-width: 576px) {
        .step-circle {
            width: 40px;
            height: 40px;
            font-size: 12px;
        }

        .step-label {
            font-size: 10px;
        }
    }
</style>
