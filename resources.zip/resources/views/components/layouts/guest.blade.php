<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    @include('livewire.components.seo')

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Karla:ital,wght@0,200..800;1,200..800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Spectral:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
        rel="stylesheet">

    @stack('styles')

    @livewireStyles
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
    <div class="wrapper">
        @include('components.includes.front-header')
        <div class="page-wrapper">
            <div class="page-content">
                {{ $slot }}
            </div>
        </div>
    </div>
    @include('components.includes.front-footer')

    @livewireScripts

    @if (session('success'))
    <script>
        window.addEventListener("DOMContentLoaded", function () {
            window.dispatchEvent(new CustomEvent("swal:toast", {
                detail: [{
                    type: "success",
                    message: "{{ session('success') }}"
                }]
            }));
        });
    </script>
    @endif

    @if (session('error'))
    <script>
        window.addEventListener("DOMContentLoaded", function () {
            window.dispatchEvent(new CustomEvent("swal:toast", {
                detail: [{
                    type: "error",
                    message: "{{ session('error') }}"
                }]
            }));
        });
    </script>
    @endif

    @stack('scripts')

</body>

</html>
